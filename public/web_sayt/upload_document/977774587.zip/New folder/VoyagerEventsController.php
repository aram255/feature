<?php

namespace App\Http\Controllers\Voyager;
use App\Models\Event;
use App\Services\Calendar;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;


class VoyagerEventsController extends \App\Http\Controllers\Controller
{
    public $calendar;
    public function __construct(Calendar $calendar)
    {
        $this->calendar = $calendar;
    }
    public function index(Request $request)
    {
        $this->calendar->setCallbacks(['dayClick' => 'function(day,aaa) {$(this).css("background-color", "lightgreen");$(".clickNote").click();$(".createEvent").click();
            function convert(str) {
                var date = new Date(str),mnth = ("0" + (date.getMonth() + 1)).slice(-2),day = ("0" + date.getDate()).slice(-2);
                hour = "T00:00";
                return [date.getFullYear(),mnth,day].join("-") + hour;
            }
            dateTime=convert(day._d);
            var elem=document.getElementById("meeting");
            elem.value = dateTime;
            }',
            'eventClick'=> 'function(event,aaa){$(".edit_event").click()
            $("#apply-now-form .event").val(event.id);
            $("#editEvent .eventEdit").val(event.id);
            function pad(n){return n<10 ? "0"+n : n}
            function convert(str) {
                var date = new Date(str),mnth = ("0" + (date.getMonth() + 1)).slice(-2),day = ("0" + date.getDate()).slice(-2),
                hour = "T" + pad(date.getUTCHours())+":" + pad(date.getUTCMinutes())+":"+ pad(date.getUTCSeconds());
                return [date.getFullYear(),mnth,day].join("-") + hour;
            }
            start=convert(event.start._i);end=convert(event.end._i);
            event_start_date=document.getElementById("meeting-time");
            event_end_date=document.getElementById("meeting-time-end");
            event_start_date.value=start;event_end_date.value=end;

                $.ajax({
                    url: "'.route('voyager.notes.list').'",
                    method: "post",
                    data: {_token:$(\'meta[name="csrf-token"]\').attr(\'content\'), id: event.id},
                    success: (response) => {
                     let items = [];
                    $(response).each(function(i){items.push(`<div class="dashboard-note"  id="${response[i].event_id}"><p class="noteText" data-id="${response[i].id}">${response[i].description}</p><div class="note-footer"><span class="note-priority ${response[i].priority.toLowerCase()}">${response[i].priority} priority</span><div class="note-buttons"><a href="" data-id="${response[i].id}" class="edit-note" title="Edit" data-toggle="modal" data-target="#exampleModalCenteredit" data-tippy-placement="top"><i class="icon-feather-edit-dsh"></i></a><a href=""  class="remove" title="Delete" data-id="${response[i].id}" data-tippy-placement="top" data-toggle="modal" data-target="#exampleModalCentereventdel"><i class="icon-feather-trash-2-dsh"></i></a></div></div></div>`);
                    $(".notes").html(items);
                    $(".editNote").val($(".edit-note").data("id"));
                    $(".delNote").val($(".remove").data("id"));
                    $(".note-description").empty().val($(".noteText").text());
                     var $styledSelect = $(".select-styled");
                      $styledSelect.text($(".note-priority").text()).addClass("active");
                        })
                        }
                    });
              $(".editable").val(event.title);
              $(".event-select").val(event[0]);
              $(".eventDetails").text(event[1]);
              }',
        ]);
        $events = [];
        $data = Event::all();
        if ($data->count()) {
            foreach ($data as $key => $value) {
                $events[] = $this->calendar->event(
                    $value->title,
                    null,
                    new \DateTime($value->start_date),
                    new \DateTime($value->end_date),
                    $value->id,
                    [$value->type,$value->details]
                );
            }
        }
        $calendar = $this->calendar->addEvents($events);
        $calendarId = $this->calendar->getId();

        return view('vendor.voyager.home.dashboard', compact('calendar','calendarId'));
    }
    public function addNewEvent(Request $r)
    {
        $event = new Event();
        $event->fill($r->all());
        $event->user_id=Auth::user()->id;
        $event->save();
        return Redirect::to('/admin/');
    }
    function updates(Request $r) {
        Event::find($r->event_edit_id)->fill($r->all())->save();
        return Redirect::to('/admin/');
    }

}



