<?php

namespace App\Services;



use Illuminate\Support\Str;
use LaravelFullCalendar\SimpleEvent;

class Calendar extends \LaravelFullCalendar\Calendar
{

    /**
     * Create the <div> the calendar will be rendered into
     *
     * @return string
     */
    public function calendar()
    {

        return '<div id="calendar-' . $this->getId() . '"></div>';
    }
    /**
     * Replace placeholders with non-JSON encoded values
     *
     * @param $json
     * @param $placeholders
     * @return string
     */
    protected function replaceCallbackPlaceholders($json, $placeholders)
    {
        $search  = [];
        $replace = [];

        foreach ($placeholders as $name => $placeholder) {
            $search[]  = '"' . $placeholder . '"';
            $replace[] = $this->getCallbacks()[$name];
        }

        foreach ($search as $i => $s){
            $json = str_replace($s, $replace[$i], $json);
        }
        return $json;
        preg_replace_callback_array();
        return Str::replaceArray($search, $replace, $json);
    }
}
