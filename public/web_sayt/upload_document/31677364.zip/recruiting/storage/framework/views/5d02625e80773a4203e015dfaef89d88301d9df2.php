<div class="modal fade modal-withdraw"  id="exampleModalCenteredit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered d-flex justify-content-center align-items-center" style="height: 870px;" role="document">
        <div class="modal-content w-100">
            <div style="padding: 20px 45px 50px;">
                <div class="welcome-text">
                    <h3>Edit <b>Note</b></h3>
                </div>
                <!-- Form -->
                <form method="post" action="<?php echo e(route('voyager.event-notes.update',$notes->getKey())); ?>" id="note_edit" class="add-to-do" >
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" class="editNote" name="note_id">
                    <p>Details</p>
                    <div class="input-with-icon-left">
                        <div class="form-group">
                            <div>
                                <textarea name="description" class="form-control note-description" cols="30" rows="10" placeholder="Meeting with candidate at 3pm who applied for Billingual Event Support Specialist"></textarea>
                            </div>
                        </div>
                        <select name="priority" class="notePriority">
                            <option value="LOW">LOW</option>
                            <option value="MEDIUM" selected>MEDIUM</option>
                            <option value="HIGH">HIGH</option>
                        </select>
                    </div>
                    <div class="withdraw-notes">
                        <button type="button" class="notes-close btn btn-secondary" data-dismiss="modal">Cancel
                        </button>
                        <button type="submit" class="save-event button btn-primary">Save</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/notes/index.blade.php ENDPATH**/ ?>