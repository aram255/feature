

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/dragAndDrop.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="single-page-header" style="background-color: #FFFFFF; margin-bottom: 0;">
        <div class="container">
            <div class="d-flex justify-content-between" style="position: relative; left: -24px">
                <div>
                    <a href="roles-grid.html">
                        <img src="/images/rec_images/Arrow%20-%20Left.png" alt="">
                    </a>
                </div>
            </div>

        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 ">
                <div class="role-title">
                    <div class="d-flex justify-content-between">
                        <h3><?php echo e($job->name); ?> </h3>
                        <a href="#"><img src="/images/rec_images/Edit.png" alt=""></a>
                    </div>
                    <div class="row d-flex justify-content-between">
                        <div class="col-lg-3">
                            <div class="d-flex margin-bottom-30">
                                <span class=" margin-right-40">
                                    Type
                                </span>
                                <span>
                                    <?php echo e($job->type->name ?? ''); ?>

                                </span>
                            </div>
                            <div>
                                <span>
                                    Location
                                </span>
                                <h4>
                                    <?php echo e($job->location); ?>

                                </h4>
                            </div>
                            <div>
                                <span>
                                    Hiring Manager
                                </span>
                                <h4>

                                </h4>
                            </div>
                            <div>
                                <span>
                                    Salary Range
                                </span>
                                <h4>
                                    $<?php echo e($job->start_range); ?> USD to $<?php echo e($job->end_range); ?> USD
                                </h4>
                            </div>
                        </div>
                        <div class="col-lg-5 role-title-text">
                            <h4>Job Description</h4>
                            <p>
                                <?php echo e($job->description); ?>

                            </p>

                        </div>
                        <div class="col-lg-4" >
                            <div class="sidebar-widget">
                                <div >
                                    <h3>Tags</h3>

                                    <div class="skills-prof tags-container">
                                        <?php $__currentLoopData = $job->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tag">
                                                <input type="checkbox" />
                                                <label for="tag1"><?php echo e($tag->name); ?></label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


            <div class="col-xl-12 col-lg-12 ">
                <form action="<?php echo e(route('voyager.jobs.addCandidate', ['id' => $job->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="col-xl-6 d-flex justify-content-between">
                        <div class="submit-field  w-100 margin-bottom-50 margin-right-20">
                            <h5>Candidates</h5>
                            <div class="keywords-container">
                                <div class="keyword-input-container">
                                    <select class="form-control select2 keyword-input with-border " name="candidates[]" multiple>
                                        <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($candidate->id); ?>" ><?php echo e($candidate->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                </div>

                                
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center">
                            <button type="submit" class="button ripple-effect big "  style="width: 150px">Add</button>
                        </div>
                    </div>

                </form>
            </div>











            <!-- Content -->
            <div class="col-xl-8 col-lg-8 content-right-offset">
                <div class="row margin-top-50">
                    <div class="col-3 text-center card-title">
                        <p>Lead</p>
                    </div>
                    <div class="col-3 text-center card-title">
                        <p>Screen</p>
                    </div>
                    <div class="col-3 text-center card-title">
                        <p>Interview</p>
                    </div>
                    <div class="col-3 text-center card-title">
                        <p>Offer</p>
                    </div>
                </div>
                <div class="d-flex justify-content-around card-widget row margin-bottom-40">
                    <div id="lead" class="connectedSortable col-3">
                        <?php $__currentLoopData = $job->leadCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="ui-state-default" data-id="<?php echo e($candidate->getOriginal('pivot_id')); ?>">
                            <div class="card">
                                <div>
                                    <p><?php echo e($candidate->range->name); ?></p>
                                    <h3><?php echo e($candidate->name); ?></h3>

                                    <a class="viwe-profile" href="<?php echo e(route("voyager.candidates.show", $candidate->id)); ?>">
                                        View Profile
                                    </a>

                                </div>
                                <div class="card-link">
                                    <a class="link-tel" href="tel:+61 123-456-789"><?php echo e($candidate->phone); ?></a>
                                    <a href="#">
                                        <?php echo e($candidate->email); ?>

                                    </a>
                                    <br>
                                    <div class="d-flex justify-content-between">
                                        <a href="#">
                                            <?php echo e($candidate->linkdin); ?>

                                        </a>
                                        <span class="card-dell"></span>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                    <div id="screen" class="connectedSortable col-3">
                        <?php $__currentLoopData = $job->screenCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="ui-state-default" data-id="<?php echo e($candidate->getOriginal('pivot_id')); ?>">
                                <div class="card">
                                    <div>
                                        <p><?php echo e($candidate->range->name); ?></p>
                                        <h3><?php echo e($candidate->name); ?></h3>

                                        <a class="viwe-profile" href="<?php echo e(route("voyager.candidates.show", $candidate->id)); ?>">
                                            View Profile
                                        </a>

                                    </div>
                                    <div class="card-link">
                                        <a class="link-tel" href="tel:+61 123-456-789"><?php echo e($candidate->phone); ?></a>
                                        <a href="#">
                                            <?php echo e($candidate->email); ?>

                                        </a>
                                        <br>
                                        <div class="d-flex justify-content-between">
                                            <a href="#">
                                                <?php echo e($candidate->linkdin); ?>

                                            </a>
                                            <span class="card-dell"></span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div id="interview" class="connectedSortable col-3">
                        <?php $__currentLoopData = $job->interviewCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="ui-state-default" data-id="<?php echo e($candidate->getOriginal('pivot_id')); ?>">
                                <div class="card">
                                    <div>
                                        <p><?php echo e($candidate->range->name); ?></p>
                                        <h3><?php echo e($candidate->name); ?></h3>

                                        <a class="viwe-profile" href="<?php echo e(route("voyager.candidates.show", $candidate->id)); ?>">
                                            View Profile
                                        </a>

                                    </div>
                                    <div class="card-link">
                                        <a class="link-tel" href="tel:+61 123-456-789"><?php echo e($candidate->phone); ?></a>
                                        <a href="#">
                                            <?php echo e($candidate->email); ?>

                                        </a>
                                        <br>
                                        <div class="d-flex justify-content-between">
                                            <a href="#">
                                                <?php echo e($candidate->linkdin); ?>

                                            </a>
                                            <span class="card-dell"></span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div id="offer" class="connectedSortable col-3">
                        <?php $__currentLoopData = $job->offerCandidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="ui-state-default" data-id="<?php echo e($candidate->getOriginal('pivot_id')); ?>">
                                <div class="card">
                                    <div>
                                        <p><?php echo e($candidate->range->name); ?></p>
                                        <h3><?php echo e($candidate->name); ?></h3>

                                        <a class="viwe-profile" href="<?php echo e(route("voyager.candidates.show", $candidate->id)); ?>">
                                            View Profile
                                        </a>

                                    </div>
                                    <div class="card-link">
                                        <a class="link-tel" href="tel:+61 123-456-789"><?php echo e($candidate->phone); ?></a>
                                        <a href="#">
                                            <?php echo e($candidate->email); ?>

                                        </a>
                                        <br>
                                        <div class="d-flex justify-content-between">
                                            <a href="#">
                                                <?php echo e($candidate->linkdin); ?>

                                            </a>
                                            <span class="card-dell"></span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <!-- Sidebar -->
            <div class="col-xl-4 col-lg-4">
                <div class="sidebar-container">

                    <a href="" class="btn message-button  popup-with-zoom-anim" data-toggle="modal" data-target="#exampleModalCenter">Add Note
                        <!--                        <i class="icon-material-outline-arrow-right-alt"></i>-->
                    </a>

                    <!-- Modal -->
                    <div class="modal fade modal-withdraw"  id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered d-flex justify-content-center align-items-center" style="height: 870px;" role="document">
                            <div class="modal-content w-100">
                                <div style="    padding: 20px 45px 50px;">
                                    <div class="welcome-text">
                                        <h3>Withdraw [Name]</h3>
                                    </div>

                                    <!-- Form -->
                                    <form method="post" id="apply-now-form">
                                        <p>Notes</p>
                                        <div class="input-with-icon-left">
                                            <div class="form-group">
                                                <div>
                                            <textarea name="user-message" id="user-message" class="form-control" cols="30" rows="5"
                                                      placeholder="reason for withdraw / feedback "></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <div class="withdraw-notes">
                                        <button type="button" class="notes-close btn btn-secondary" data-dismiss="modal">Cancel
                                        </button>
                                        <button type="button" class="withdraw  btn-primary">Withdraw</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Sidebar Widget -->
                    <div class="sidebar-widget margin-bottom-0">
                        <div class="sidebar-title">
                            <h3>Title</h3>
                            <div class="d-flex justify-content-between">
                                <div>
                                    <span>
                                        Note Creator
                                    </span>
                                    <p>Note details</p>
                                </div>
                                <p>August <br> 2019</p>
                            </div>

                        </div>

                    </div>
                    <!-- Sidebar Widget -->
                    <div class="sidebar-widget margin-bottom-0" >
                        <div class="sidebar-title sidebar-title-bg">
                            <h3>Title</h3>
                            <div class="d-flex justify-content-between">
                                <div>
                                    <span>
                                        Note Creator
                                    </span>
                                    <p>Note details</p>
                                </div>
                                <p>August <br> 2019</p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('before-script'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
    <script>
        $( function() {
            $( "#lead, #screen, #interview, #offer" ).sortable({
                update: function(event, ui) {
                    let id = $(ui.item).data('id');
                    let progress = $(event.target).attr('id');

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    jQuery.ajax({
                        url: "<?php echo e(route('voyager.jobs.dragdrop', ['id' => $job->id])); ?>",
                        method: 'POST',
                        data: {
                            id: id,
                            progress: progress,
                        },
                        success: function(result){
                            console.log(result);
                        }});




                },
                connectWith: ".connectedSortable"
            }).disableSelection();
        } );
    </script>


    <script>
        $(document).ready(function () {
            $('.select2').select2();

            $("#multipleSelectExample").click(function () {
                $(".select2").select2("open");
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/jobs/read.blade.php ENDPATH**/ ?>