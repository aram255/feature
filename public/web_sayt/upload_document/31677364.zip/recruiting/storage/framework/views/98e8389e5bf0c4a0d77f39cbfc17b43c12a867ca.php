<header id="header-container" class="fullwidth dashboard-header not-sticky">

    <!-- Header -->
    <div id="header">
        <div class="container">

            <!-- Left Side Content -->
            <div class="left-side">

                <!-- Logo -->
                <div id="logo">
                    <a href="<?php echo e(route('voyager.dashboard')); ?>"><img src="<?php echo e(\Voyager::image( setting('admin.icon_image') )); ?>" alt=""></a>
                </div>

                <!-- Main Navigation -->
                <?php echo $__env->make('voyager::dashboard.navbar_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Main Navigation / End -->

            </div>
            <!-- Left Side Content / End -->


            <!-- Right Side Content / End -->
            <div class="right-side">

                <!--  User Notifications -->
                <div class="header-widget hide-on-mobile">

                    <!-- Notifications -->
                    <div id="event-header-notifications" class="header-notifications">

                        <!-- Trigger -->
                        <div class="header-notifications-trigger">
                            <a href="#"><i class="icon-feather-bell"></i><span id="event-notifications-count"><?php echo e($notificationsCount); ?></span></a>
                        </div>

                        <!-- Dropdown -->
                        <div class="header-notifications-dropdown">

                            <div class="header-notifications-headline">
                                <h4>Notifications</h4>
                                <button class="mark-as-read ripple-effect-dark" title="Mark all as read" data-tippy-placement="left">
                                    <i class="icon-feather-check-square"></i>
                                </button>
                            </div>

                            <div class="header-notifications-content">
                                <div class="header-notifications-scroll" data-simplebar>
                                    <ul id="event-notifications">
                                        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $not): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $not; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Messages -->
                    <div class="header-notifications">
                        <div class="header-notifications-trigger">
                            <a href="#"><i class="icon-feather-mail"></i><span>3</span></a>
                        </div>
                        <!-- Dropdown -->
                        <div class="header-notifications-dropdown">
                            <div class="header-notifications-headline">
                                <h4>Messages</h4>
                                <button class="mark-as-read ripple-effect-dark" title="Mark all as read" data-tippy-placement="left">
                                    <i class="icon-feather-check-square"></i>
                                </button>
                            </div>
                            <div class="header-notifications-content">
                                <div class="header-notifications-scroll" data-simplebar>
                                    <ul>
                                        <!-- Notification -->
                                        <li class="notifications-not-read">
                                            <a href="dashboard-messages.html">
                                                <span class="notification-avatar status-online"><img src="/images/rec_images/prof-d.png" alt=""></span>
                                                <div class="notification-text">
                                                    <strong>David Peterson</strong>
                                                    <p class="notification-msg-text">Thanks for reaching out. I'm quite busy right now on many...</p>
                                                    <span class="color">4 hours ago</span>
                                                </div>
                                            </a>
                                        </li>

                                        <!-- Notification -->
                                        <li class="notifications-not-read">
                                            <a href="dashboard-messages.html">
                                                <span class="notification-avatar status-offline"><img src="/images/rec_images/prof-s.png" alt=""></span>
                                                <div class="notification-text">
                                                    <strong>Sindy Forest</strong>
                                                    <p class="notification-msg-text">Hi Tom! Hate to break it to you, but I'm actually on vacation until...</p>
                                                    <span class="color">Yesterday</span>
                                                </div>
                                            </a>
                                        </li>

                                        <!-- Notification -->
                                        <li class="notifications-not-read">
                                            <a href="dashboard-messages.html">
                                                <span class="notification-avatar status-online"><img src="/images/rec_images/list-grid-img.png" alt=""></span>
                                                <div class="notification-text">
                                                    <strong>Marcin Kowalski</strong>
                                                    <p class="notification-msg-text">I received payment. Thanks for cooperation!</p>
                                                    <span class="color">Yesterday</span>
                                                </div>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <a href="dashboard-messages.html" class="header-notifications-button ripple-effect button-sliding-icon">View All Messages<i class="icon-material-outline-arrow-right-alt"></i></a>
                        </div>
                    </div>
                </div>
                <!--  User Notifications / End -->
                <!-- User Menu -->
                <div class="header-widget">
                    <!-- Messages -->
                    <div class="header-notifications user-menu">
                        <div class="header-notifications-trigger">
                            <a href="#"><div class="user-avatar status-online"><img src="<?php echo e(\Voyager::image(\Auth::user()->avatar)); ?>" alt=""></div></a>
                        </div>
                        <!-- Dropdown -->
                        <div class="header-notifications-dropdown">
                            <!--							&lt;!&ndash; User Status &ndash;&gt;-->
                            <!--							<div class="user-status">-->

                            <!--								&lt;!&ndash; User Name / Avatar &ndash;&gt;-->
                            <!--								<div class="user-details">-->
                            <!--									<div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div>-->
                            <!--									<div class="user-name">-->
                            <!--										Tom Smith <span>Freelancer</span>-->
                            <!--									</div>-->
                            <!--								</div>-->

                            <!--								&lt;!&ndash; User Status Switcher &ndash;&gt;-->
                            <!--								<div class="status-switch" id="snackbar-user-status">-->
                            <!--									<label class="user-online current-status">Online</label>-->
                            <!--									<label class="user-invisible">Invisible</label>-->
                            <!--									&lt;!&ndash; Status Indicator &ndash;&gt;-->
                            <!--									<span class="status-indicator" aria-hidden="true"></span>-->
                            <!--								</div>-->
                            <!--							</div>-->

                            <ul class="user-menu-small-nav">

                                <li><a href="dashboard-settings.html"><i class="icon-material-outline-settings"></i> Settings</a></li>





                                <li class="logout">
                                    <form action="<?php echo e(route('voyager.logout')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                    <a href="javascript:void(0)"><i class="icon-material-outline-power-settings-new"></i> Logout</a>
                                </li>
                            </ul>

                        </div>
                    </div>
                </div>
                <!-- User Menu / End -->

                <!-- Mobile Navigation Button -->
                <span class="mmenu-trigger">
					<button class="hamburger hamburger--collapse" type="button">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</button>
				</span>

            </div>
            <!-- Right Side Content / End -->

        </div>
    </div>
    <!-- Header / End -->

</header>
<div class="clearfix"></div>
<?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/partials/header.blade.php ENDPATH**/ ?>