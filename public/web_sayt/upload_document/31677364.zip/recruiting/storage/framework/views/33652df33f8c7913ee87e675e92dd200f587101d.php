<?php $__env->startSection('content'); ?>
    <?php echo e($notes); ?>

    <div class="dashboard-container">
        <!--sitebar	-->
        <div class="dashboard-sidebar">
            <div class="dashboard-sidebar-inner" data-simplebar>
                <div class="dashboard-nav-container">
                    <a href="#" class="dashboard-responsive-nav-trigger">
					<span class="hamburger hamburger--collapse" >
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</span>
                        <span class="trigger-title">Dashboard Navigation</span>
                    </a>
                    <div class="dashboard-nav">
                        <div class="dashboard-nav-inner">

                            <ul data-submenu-title="">
                                <li class="active"><a href="dashboard.html"><i class="icon-material-outline-dashboard"></i> Dashboard</a></li>
                                <li><a href="dashboard-messages.html"><i class="icon-material-outline-question-answer"></i> Messages <span class="nav-tag">2</span></a></li>
                                <li><a href="dashboard-notes.html"><i class="icon-material-outline-note-add"></i> Notes </a></li>
                            </ul>
                            <ul>
                                <li class="active-submenu">
                                    <a href="#">
                                        <i class="icon-material-outline-star-border"></i>Roles
                                    </a>
                                    <ul>
                                        <li><a href="#">Active</a></li>
                                        <li><a href="new-role.html">New Role</a></li>
                                        <li><a href="#">Archived</a></li>
                                    </ul>
                                </li>
                                <li  class="active-submenu">
                                    <a href="#">
                                        <i class="icon-material-candidates"></i>Candidates
                                    </a>
                                    <ul data-submenu-title="Candidates">
                                        <li><a href="#">All</a></li>
                                        <li><a href="#">New Profile</a></li>
                                        <li><a href="priority-hire.html">Priority Hire</a></li>
                                    </ul>

                                </li>
                                <li  class="active-submenu">
                                    <a href="#">
                                        <i class="icon-material-outline-settings"></i>Account
                                    </a>
                                    <ul data-submenu-title="Account">
                                        <li><a href="dashboard-team.html"> Team </a></li>
                                        <li><a href="dashboard-settings.html"> Settings</a></li>
                                        <li><a href="index-logged-out.html"> Logout</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--sitebar	-->
        <!--	-->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner" >

                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <h3>Howdy, Tom!</h3>
                    <span>We are glad to see you again!</span>

                    <!-- Breadcrumbs -->
                    <!--				<nav id="breadcrumbs" class="dark">-->
                    <!--					<ul>-->
                    <!--						<li><a href="#">Home</a></li>-->
                    <!--						<li>Dashboard</li>-->
                    <!--					</ul>-->
                    <!--				</nav>-->
                </div>
                <div class="row">

                    <div class="col-xl-8 dashboard-box">
                        <div id="wrapper">
                            <form method="post" action="<?php echo e(url('/admin/addNewEvent')); ?>" enctype="multipart/form-data" class="w-25  bg-dark text-white mx-auto">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Title</label>
                                    <input type="text" name="title" class="mb-3 form-control" style="border:1px solid black"value="<?php echo e(old('title')); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Start date</label>
                                    <input type="date" name="start_date" class="mb-3 form-control" style="border:1px solid black" value="<?php echo e(old('start_date')); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">End date</label>
                                    <input type="date" name="end_date" class="mb-3 form-control" style="border:1px solid black"value="<?php echo e(old('end_date')); ?>">
                                </div>
                                <button type="submit" class="primary">Add event</button>
                            </form>
                        </div>
                    </div>
                    <div class="col-xl-4">
                        <div  class="pipeline-space">
                            <h3 >Pipelines
                                <img src="../images/rec_images/Activity.png" alt="" style="margin-left: 10px" width="20" height="20">
                            </h3>
                            <ul class="list-unstyled">
                                <li>34 Active Roles</li>
                                <li>38 Leeds</li>
                                <li>35 Phone Screens</li>
                                <li>25 Interviewing</li>
                            </ul>
                        </div>
                        <div class="dashboard-box child-box-in-row">
                            <div class="headline">
                                <h3><i class="icon-material-outline-note-add"></i> Notes</h3>
                            </div>
                            <div class="content with-padding">
                                <!-- Note -->
                                <div class="dashboard-note">
                                    <p>Meeting with candidate at 3pm who applied for Bilingual Event Support Specialist</p>
                                    <div class="note-footer">
                                        <span class="note-priority high">High Priority</span>
                                        <div class="note-buttons">
                                            <a href="#" title="Edit" data-tippy-placement="top"><i class="icon-feather-edit"></i></a>
                                            <a href="#" title="Remove" data-tippy-placement="top"><i class="icon-feather-trash-2"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="dashboard-note">
                                    <p>Extend premium plan for next month</p>
                                </div>
                            </div>
                            <div class="add-note-button">
                                <a href="#small-dialog" class="popup-with-zoom-anim button full-width button-sliding-icon">Add Note <i class="icon-material-outline-arrow-right-alt"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="dashboard-footer-spacer"></div>
        </div>
    </div>
    <!-- -->
    </div>
    <script>
        // $(document).ready(function() {
        //     $('.create').on('click',function() {
        //         $('#MyForm').toggle(500);
        // })
        // });
    </script>
<?php $__env->stopSection(); ?>






<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/notes/notes.blade.php ENDPATH**/ ?>