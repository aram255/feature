

<div class="row">
    <div class="col-md-12">
        <!-- Pagination -->
        <div class="pagination-container margin-top-30 margin-bottom-60">
            <?php if($paginator->hasPages()): ?>
                <nav class="pagination">
                    <ul>
                        
                        <?php if($paginator->onFirstPage()): ?>
                            <li class="pagination-arrow" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                                <a href="#">
                                    <i class="icon-material-outline-keyboard-arrow-left"></i>
                                </a>
                            </li>
                        <?php else: ?>
                            <li class="pagination-arrow"><a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>"><i
                                        class="icon-material-outline-keyboard-arrow-left"></i></a></li>

                        <?php endif; ?>

                        
                        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if(is_string($element)): ?>
                                <li class="disabled" aria-disabled="true"><span><?php echo e($element); ?></span></li>
                            <?php endif; ?>

                            
                            <?php if(is_array($element)): ?>
                                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($page == $paginator->currentPage()): ?>
                                        <li aria-current="page"><a href="#" class="current-page"><?php echo e($page); ?></a></li>
                                    <?php else: ?>
                                        <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php if($paginator->hasMorePages()): ?>
                            <li class="pagination-arrow"><a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>"><i
                                        class="icon-material-outline-keyboard-arrow-right"></i></a></li>
                        <?php else: ?>
                            <li class="pagination-arrow" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                                <a href="#">
                                <i class="icon-material-outline-keyboard-arrow-right"></i>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</div>





<?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/pagination/custom.blade.php ENDPATH**/ ?>