<?php
    $edit = !is_null($candidate->getKey());
    $add  = is_null($candidate->getKey());
?>



<?php $__env->startSection('content'); ?>
    <div class="dashboard-container container">



        <!-- Dashboard Content
        ================================================== -->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner" >

                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <div class="d-flex justify-content-between new-condidate-title">
                        <h3>New Candidate</h3>
                        <p>
                            <a href="#">Cancel</a>
                        </p>
                    </div>
                </div>

                <!-- Row -->
                <div class="row">
                    <!-- Dashboard Box -->
                    <div class="col-xl-12">
                        <div class="dashboard-box margin-top-0">
                            <!-- Headline -->
                            <div class="headline">
                                <h3>Details</h3>
                            </div>
                            <div class="content with-padding padding-bottom-10">
                                <form  action="<?php echo e($edit ? route('voyager.candidates.update', $candidate->getKey()) : route('voyager.candidates.store')); ?>"
                                       method="POST" enctype="multipart/form-data">
                                    <!-- PUT Method if we are editing -->
                                    <?php if($edit): ?>
                                        <?php echo method_field('PUT'); ?>
                                    <?php endif; ?>
                                    <?php echo csrf_field(); ?>
                                    <div class="row new-condidate-inp">

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Name</h5>
                                                <input type="text" class="with-border" placeholder="Full Name" name="name" value="<?php echo e($candidate->name); ?>">
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Open To</h5>
                                                <select name="type_id" class="selectpicker with-border" data-size="7" title="Select Job Type">
                                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($type->id); ?>"  <?php if($type->id == $candidate->type_id): ?> selected="selected" <?php endif; ?>><?php echo e($type->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Job Category</h5>
                                                <select name="range_id" class="selectpicker with-border" data-size="7" title="Select Category">
                                                    <?php $__currentLoopData = $ranges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($range->id); ?>" <?php if($range->id == $candidate->range_id): ?> selected="selected" <?php endif; ?>><?php echo e($range->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Current Title</h5>
                                                <input type="text" class="with-border">
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Location
                                                    <i class="icon-material-outline-location-on"></i>
                                                    <!--                                                <img src="" alt="">-->
                                                </h5>
                                                <div class="input-with-icon">
                                                    <div id="autocomplete-container">
                                                        <input id="autocomplete-input" class="with-border" type="text" name="location" value="<?php echo e($candidate->location); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Salary Expectations</h5>
                                                <div class="row">
                                                    <div class="col-xl-6">
                                                        <div class="input-with-icon">
                                                            <input class="with-border" type="text" name="start_price" value="<?php echo e($candidate->start_price); ?>">
                                                            <i class="currency">USD</i>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-6">
                                                        <div class="input-with-icon">
                                                            <input class="with-border" type="text" name="end_price" value="<?php echo e($candidate->end_price); ?>">
                                                            <i class="currency">USD</i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Skills <span>(optional)</span>  </h5>
                                                <div class="keywords-container">
                                                    <div class="keyword-input-container">
                                                        <select class="form-control select2 keyword-input with-border" name="skills[]" multiple>
                                                            <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($skill->id); ?>" <?php if(in_array($skill->id, $candidate->skills->pluck('id')->toArray())): ?> selected="selected" <?php endif; ?>><?php echo e($skill->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <button id="multipleSelectExample" class="keyword-input-button-1 ripple-effect"><i class="icon-material-outline-add"></i></button>
                                                    </div>
                                                    <div class="keywords-list"><!-- keywords go here --></div>
                                                    <div class="clearfix"></div>
                                                </div>
                                            </div>
                                            </div>


                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>LinkedIn</h5>
                                                <input type="text" class="with-border" placeholder="URL" name="linkdin" value="<?php echo e($candidate->linkdin); ?>">
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Email</h5>
                                                <input type="email" class="with-border" name="email" value="<?php echo e($candidate->email); ?>">
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Phone</h5>
                                                <input type="number" class="with-border" name="phone" value="<?php echo e($candidate->phone); ?>">
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Website / Portfolio</h5>
                                                <input type="text" class="with-border" name="portfolio" value="<?php echo e($candidate->portfolio); ?>">
                                            </div>
                                        </div>

                                        <div class="col-xl-12">
                                            <div class="submit-field d-flex margin-right-20">
                                                <div class=" margin-top-40">
                                                    <input class="prof-images" type="file" id="upload-img" accept="image/*, application/pdf" name="image" multiple/>
                                                    <label class="prof-images-label " for="upload-img">Upload Images</label>
                                                </div>
                                                <div>
                                                    <?php if($candidate->image): ?>
                                                        <img style="width: 70px;height: 70px;margin: 20px;border-radius: 50%;" src="<?php echo e(\Voyager::image($candidate->image)); ?>">
                                                    <?php endif; ?>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="col-xl-12">
                                            <div class="submit-field">
                                                <h5>About / Summary</h5>
                                                <textarea cols="30" rows="5" class="with-border" name="about"><?php echo e($candidate->about); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="row history">
                                        <h4>History</h4>
                                        </div>
                                     <div class="row candidate">
                                         <?php $__currentLoopData = $candidate->histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row">
                                            <div class="headline col-xl-12 employent">
                                                <h3>Employment History</h3>
                                            </div>
                                            <input type="hidden" value="<?php echo e($history->id); ?>" name="history_id[]">
                                            <div class="col-xl-3">
                                                <div class="submit-field">
                                                    <h5>Title</h5>
                                                    <input type="text" name="history_title[]" class="with-border" value="<?php echo e($history->title); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xl-3">
                                                <div class="submit-field">
                                                    <h5>Company</h5>
                                                    <input type="text" name="history_company[]" class="with-border" value="<?php echo e($history->company); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xl-2">
                                                <div class="submit-field">
                                                    <h5>From</h5>
                                                    <input type="date" name="history_start_date[]" class="with-border start_date" value="<?php echo e($history->start_date); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xl-2">
                                                <div class="submit-field">
                                                    <h5>To</h5>
                                                    <input type="date" name="history_end_date[]" class="with-border end_date" value="<?php echo e($history->end_date); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xl-10">
                                                <div class="submit-field">
                                                    <h5>Description</h5>
                                                    <textarea cols="20" rows="2" name="history_description[]" class="with-border" value=""><?php echo e($history->description); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="col-xl-12 inp-hr">
                                            </div>
                                        </div>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </div>


                                        <div class="col-xl-12 d-flex justify-content-center">
                                            <button class="add-new-button newHistory">Add new
                                            </button>
                                        </div>
                                        <div class="uploadButton col-xl-6 margin-top-30">
                                                <input class="uploadButton-input" type="file" accept="image/*, application/pdf" id="upload" name="files[]" multiple/>
                                                <label class="uploadButton-button ripple-effect" for="upload">Upload Files</label>
                                            <?php if($candidate->files && json_decode($candidate->files)): ?>
                                                <div>
                                                <?php $__currentLoopData = json_decode($candidate->files); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <span class="uploadButton-file-name d-block">
                                                        <a class="fileType" target="_blank"
                                                           href="<?php echo e(Storage::disk(config('voyager.storage.disk'))->url($file->download_link) ?: ''); ?>">
                                                            <?php echo e($file->original_name ?: ''); ?>

                                                        </a>
                                                        <a href="#" class="voyager-x remove-multi-file"></a>
                                                    </span>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            <?php else: ?>
                                                <span class="uploadButton-file-name">Resume / CV / Cover Letter / Portfolio </span>
                                            <?php endif; ?>
                                        </div>


                                        <div class="col-xl-6 justify-content-end d-flex">
                                            <button class="button ripple-effect big margin-top-30 " style="max-height: 50px;">Add Candidate</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>

                    </div>



                </div>
                <!-- Row / End -->

                <!-- Footer -->
                <div class="dashboard-footer-spacer"></div>

                <div class="clearfix"></div>
                <!-- Footer / End -->

            </div>
        </div>
        <!-- Dashboard Content / End -->

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function () {
            $('.select2').select2();

            $("#multipleSelectExample").click(function () {
                $(".select2").select2("open");
            });
            $('.newHistory').click(function (e) {
                e.preventDefault();
                $(".candidate").append(`<div class="row"><div class="headline col-xl-12 employent">
                                            <h3>Employment History</h3>
                                        </div><div class="col-xl-3">
                                    <input type="hidden" name="history_id[]">
                                            <div class="submit-field">
                                                <h5>Title</h5>
                                                <input type="text" name="history_title[]" class="with-border">
                                            </div>
                                        </div>
                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Company</h5>
                                                <input type="text" name="history_company[]" class="with-border">
                                            </div>
                                        </div>
                                        <div class="col-xl-2">
                                            <div class="submit-field">
                                                <h5>From</h5>
                                                <input type="date" name="history_start_date[]" class="with-border start_date">
                                            </div>
                                        </div>
                                        <div class="col-xl-2">
                                            <div class="submit-field">
                                                <h5>To</h5>
                                                <input type="date" name="history_end_date[]" class="with-border end_date">
                                            </div>
                                        </div>
                                        <div class="col-xl-10">
                                            <div class="submit-field">
                                                <h5>Description</h5>
                                                <textarea cols="20" rows="2" name="history_description[]" class="with-border"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-xl-12 inp-hr">
                                        </div></div>`);

            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/candidates/edit-add.blade.php ENDPATH**/ ?>