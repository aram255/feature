<!doctype html>
<html lang="en">
<head>
    <title>RecruitingTool</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/colors/blue.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/rec_style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/candidate.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
    <?php echo $__env->yieldContent('head'); ?>
    <?php echo $__env->yieldPushContent('head'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<body class="gray">
<div id="wrapper">
    <!--Header	-->
<?php echo $__env->make('voyager::partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Header	-->

    <?php echo $__env->yieldContent('content'); ?>
</div>
<!-- Apply for a job popup / End -->
<!-- Scripts
================================================== -->


<?php echo $__env->yieldContent('footer'); ?>







<script src="/js/jquery-3.4.1.min.js"></script>
<script src="/js/jquery-migrate-3.1.0.min.js"></script>

<?php echo $__env->yieldContent('before-script'); ?>
<?php echo $__env->yieldPushContent('before-script'); ?>


<script src="<?php echo e(asset('js/mmenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/tippy.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-slider.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/snackbar.js')); ?>"></script>
<script src="<?php echo e(asset('js/clipboard.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>




<!-- Snackbar // documentation: https://www.polonel.com/snackbar/ -->
<script>
    // Snackbar for user status switcher
    $('#snackbar-user-status label').click(function() {
        Snackbar.show({
            text: 'Your status has been changed!',
            pos: 'bottom-center',
            showAction: false,
            actionText: "Dismiss",
            duration: 3000,
            textColor: '#fff',
            backgroundColor: '#383838'
        });
    });
</script>

<!-- Chart.js // documentation: http://www.chartjs.org/docs/latest/ -->
<script src="<?php echo e(asset('js/chart.min.js')); ?>"></script>




<!-- Pusher -->
<script src="https://js.pusher.com/5.0/pusher.min.js"></script>
<script>
    // Enable pusher logging - don't include this in production
    Pusher.logToConsole = true;
    var pusher = new Pusher("<?php echo e(config('chatify.pusher.key')); ?>", {
        encrypted: true,
        cluster: "<?php echo e(config('chatify.pusher.options.cluster')); ?>",
        
        auth: {
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        }
    });


    // Subscribe to the channel we specified in our Laravel Event
    var channel = pusher.subscribe('viewer.<?php echo e(\Auth::user()->id); ?>');
    // Bind a function to a Event (the full Laravel class)
    channel.bind('App\\Events\\Viewer', function(data) {
        let count = $('#event-notifications-count').text();
        $('#event-notifications-count').text(parseInt(count)+1);

        $('#event-notifications').append(
            '<li class="notifications-not-read">' +
            '<a href="dashboard-manage-candidates.html"> ' +
            '<span class="notification-icon"><i class="icon-material-outline-group"></i></span> ' +
            '<span class="notification-text"> ' +
            '<strong>'+data.message.from+'</strong> '+data.message.action+' <span class="color">'+data.message.name+'</span> ' +
            '</span> </a> </li>'
        );
    });

</script>
<!-- End pusher -->








<?php echo $__env->yieldContent('script'); ?>
<?php echo $__env->yieldPushContent('script'); ?>













<script>
    $('.logout a').click(function(e) {
        e.preventDefault();
        $(this).parent().find('form').submit();

    });
</script>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/dashboard.blade.php ENDPATH**/ ?>