<div class="row">
    <?php
        $dataTypeTools = \Voyager::model('DataType')->where('slug', '=', 'tools')->first();
        $tools = app($dataTypeTools->model_name)->get();
    ?>

    <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-4 col-sm-12 col-12">
            <form action="<?php echo e(route('voyager.'.$dataTypeTools->slug.'.update', $tool->getKey())); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="pricing">
                    <div>
                        <h4><?php echo e($tool->name); ?></h4>
                        <p>
												<span>
													$<?php echo e($tool->price_month); ?>

												</span>
                            / month
                        </p>
                        <span>Billed Monthly</span>
                        <p class="text-amazing">
                            1 Users
                            <br>
                            <br>
                            Unlimited Roles & Candidates
                            <br>
                            <br>
                            Scheduling and Automation
                        </p>
                        <input type="submit" value="Select Plan">
                        <p class="free">Free 7 Day Trail</p>
                    </div>
                </div>
            </form>

        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\recruiting\resources\views/prices.blade.php ENDPATH**/ ?>