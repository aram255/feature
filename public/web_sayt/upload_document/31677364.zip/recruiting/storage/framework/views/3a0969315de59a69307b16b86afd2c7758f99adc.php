<?php $__env->startSection('content'); ?>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.js"></script>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.css"/>
        <!--sitebar	-->

























































<div id="wrapper">
        <div class="panel-body"> <?php echo $calendar->calendar(); ?> <?php echo $calendar->script(); ?> </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js"></script>

    <script>
        $(document).ready(function() {
            // page is now ready, initialize the calendar...
            $('#calendar').fullCalendar({
                // today:    'today',
                // list:     'list',
                weekends: true,
                dayClick: function() {
                    $(this).css("background-color", "lightgreen");
                },
                header: {
                    left: '',
                    right: ' ',
                    center: 'prev, title, next',
                }
            });
        });
    </script>
 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.voyager.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/calendar/mycalendar.blade.php ENDPATH**/ ?>