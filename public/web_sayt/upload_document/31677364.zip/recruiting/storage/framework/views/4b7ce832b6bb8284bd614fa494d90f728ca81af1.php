

<?php $__env->startSection('content'); ?>
    <div class="roles-grid condidate-list-grid">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-4">
                    <?php echo $__env->make('voyager::dashboard.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>


                <div class="col-xl-9 col-lg-8 content-left-offset">

                    <h3 class="page-title">Search Roles</h3>

                    <div class="input-with-icon search-roles margin-top-16 margin-bottom-52">
                        <div id="autocomplete-container">
                            <input id="autocomplete-input" type="text" placeholder="Title, Company, Req #">
                        </div>
                        <i class="icon-material-outline-search"></i>
                    </div>

                    <div class="d-flex justify-content-between p-0">
                        <div class="sort-by">
                            <span>Sort by:</span>
                            <select class="selectpicker hide-tick">
                                <option>Relevance</option>
                                <option>Newest</option>
                                <option>Oldest</option>
                                <option>Random</option>
                            </select>
                        </div>

                        <div class="grid-list d-flex">
                            <div class="grid d-flex"><i class="grid-icon"></i>
                                <p>Grid</p></div>
                            <div class="list d-flex"><i class="list-icon"></i>
                                <p>List</p></div>
                        </div>
                    </div>

                    <div class="listings-container grid-layout margin-top-16" id="candidate-grid">

                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('voyager.jobs.show', $data->id)); ?>" class="job-listing">
                                <div class="applicants-role">
                                    <p>
                                        18 applicants
                                    </p>
                                </div>
                                <!-- Job Listing Details -->
                                <div class="job-listing-details">
                                    <!-- Logo -->
                                    <div class="job-listing-company-logo">
                                        <img src="images/company-logo-05.png" alt="">
                                    </div>

                                    <!-- Details -->
                                    <div class="job-listing-description">
                                        <h4 class="job-listing-company"><?php echo e($data->name); ?></h4>
                                        <h3 class="job-listing-title"><?php echo e($data->name); ?></h3>
                                    </div>
                                </div>

                                <!-- Job Listing Footer -->
                                <div class="job-listing-footer">
                                    <div class="d-flex justify-content-between">
                                        <div class="job-info">
                                            <p> $<?php echo e($data->location); ?></p>
                                            <span>$<?php echo e($data->start_range); ?>-$<?php echo e($data->end_range); ?> </span>
                                        </div>
                                        <div class="job-info">

                                            <p>Full Time </p>
                                            <span> <?php echo e($data->created_at->diffForHumans()); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="listings-container grid-layout margin-top-16" id="candidate-list">
                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('voyager.jobs.show', $data->id)); ?>" class="job-listing">
                                <div class="applicants-role">
                                    <p>
                                        18 applicants
                                    </p>
                                </div>
                                <!-- Job Listing Details -->
                                <div class="job-listing-details roles-grid-list">
                                    <!-- Logo -->
                                    <div class="d-flex justify-content-between">
                                        <div
                                            class="job-listing-company-logo d-flex justify-content-center align-items-center">
                                            <img src="images/company-logo-05.png" alt="">
                                        </div>

                                        <!-- Details -->
                                        <div class="job-listing-description">
                                            <h4 class="job-listing-company"><?php echo e($data->name); ?></h4>
                                            <h3 class="job-listing-title"><?php echo e($data->name); ?></h3>
                                        </div>
                                    </div>
                                    <div class="job-info">
                                        <p> $<?php echo e($data->location); ?></p>
                                        <span> $<?php echo e($data->start_range); ?>-$<?php echo e($data->end_range); ?> </span>
                                    </div>
                                    <div class="job-info">

                                        <p>Full Time </p>
                                        <span> <?php echo e($data->created_at->diffForHumans()); ?></span>
                                    </div>

                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <!-- Pagination -->
                    <div class="clearfix"></div>

                    <div class="pull-right">
                        <?php echo e($jobs->links("pagination::custom")); ?>

                    </div>
                    <!-- Pagination / End -->
                </div>
            </div>
            <div class="dashboard-footer-spacer"></div>

            <div class="clearfix"></div>
            <!-- Footer / End -->
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        $(".grid").click(function () {
            $("#candidate-grid").css('display', 'flex');
            $("#candidate-list").css('display', 'none');
            $(".grid").css('color', '#2A41E8');
            $(".list").css('color', '#666666');
        })
        $(".list").click(function () {
            $("#candidate-grid").css('display', 'none');
            $("#candidate-list").css('display', 'flex');
            $(".list").css('color', '#2A41E8');
            $(".grid").css('color', '#666666');
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/jobs/browse.blade.php ENDPATH**/ ?>