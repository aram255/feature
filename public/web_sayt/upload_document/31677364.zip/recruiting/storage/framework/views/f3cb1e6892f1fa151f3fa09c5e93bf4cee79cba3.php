

<?php $__env->startPush('head'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <style>
        .mfp-bg.my-mfp-zoom-in.mfp-ready,
        .mfp-content button.mfp-close {
            display: none!important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="dashboard-container">

    <?php echo $__env->make('voyager::dashboard.sidebar_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- Dashboard Content
        ================================================== -->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner" >

                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <!--                    <h3>Bookmarks</h3>-->

                    <!-- Breadcrumbs -->
                    <!--                    <nav id="breadcrumbs" class="dark">-->
                    <!--                        <ul>-->
                    <!--                            <li><a href="#">Home</a></li>-->
                    <!--                            <li><a href="#">Dashboard</a></li>-->
                    <!--                            <li><a href="#">Candidates</a></li>-->
                    <!--                            <li>Priority Hire</li>-->
                    <!--                        </ul>-->
                    <!--                    </nav>-->
                </div>
                <!-- Row -->
                <div class="row">


                    <!-- Dashboard Box -->
                    <div class="col-xl-12">
                        <h3> Priority Hire</h3>
                        <div class="dashboard-box">


                            <!-- Headline -->
                            <div class="headline">
                                <h3> Priority Candidates</h3>
                            </div>

                            <div class="content">
                                <ul class="dashboard-box-list">
                                    <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <!-- Overview -->
                                            <div class="freelancer-overview">
                                                <div class="freelancer-overview-inner">

                                                    <!-- Avatar -->
                                                    <div class="freelancer-avatar">
                                                        <!--                                                    <div class="verified-badge"></div>-->
                                                        <a href="#">

                                                            <div class="profileImage"><?php echo e($candidate->name); ?></div>
                                                        </a>
                                                    </div>


                                                    <!-- Name -->
                                                    <div class="freelancer-name">
                                                        <h4><a href="#"><?php echo e($candidate->name); ?> <img class="flag" src="/images/flags/de.svg" alt="" title="Germany" data-tippy-placement="top"></a></h4>
                                                        <span><?php echo e($candidate->skills->pluck('name')->implode(' ')); ?></span>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Buttons -->
                                            <div class="priority-hire">
                                                <p>Priority Hire</p>
                                            </div>
                                            <div class="buttons-to-right">
                                                <a href="#" class="button red ripple-effect ico"
                                                   data-toggle="modal" data-target="#exampleModalCenter" title="Remove" data-tippy-placement="left">
                                                    <i class="icon-feather-trash-2"></i>
                                                    Remove
                                                </a>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- Row / End -->

                <!-- Footer -->
                <div class="dashboard-footer-spacer"></div>

                <!-- Footer / End -->

            </div>
        </div>
        <!-- Dashboard Content / End -->

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('before-script'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        // Snackbar for user status switcher
        $('#snackbar-user-status label').click(function() {
            Snackbar.show({
                text: 'Your status has been changed!',
                pos: 'bottom-center',
                showAction: false,
                actionText: "Dismiss",
                duration: 3000,
                textColor: '#fff',
                backgroundColor: '#383838'
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/candidates/priority.blade.php ENDPATH**/ ?>