

<?php $__env->startSection('content'); ?>
    <div class="dashboard-container">
        <!--sitebar	-->
    <?php echo $__env->make('voyager::dashboard.sidebar_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--sitebar	-->
        <!--	-->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner team-bg" >
                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <h3>Tired of working alone? Bring the team!</h3>
                    <p class="team-text">
                        Collaborating is easy, upgrade below
                    </p>
                </div>
                <div class="row container team-center">
                    <div class="col-xl-12 dashboard-box">
                        <div class="amazing padding-top-0">
                            <div class="amazing-pricing">
                                <div class="amazing-pricing-title">
                                    <div>
                                        <h1>Change Plan</h1>
                                    </div>
                                    <div>
                                        <a id="month" href="#">
                                            Monthly
                                        </a>
                                        <a id="year" href="#">
                                            Yearly
                                        </a>
                                    </div>
                                </div>
                                <?php echo $__env->make('prices', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="dashboard-footer-spacer"></div>
            </div>
        </div>
        <!-- -->
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/exception/authorization.blade.php ENDPATH**/ ?>