<?php
    $edit = !is_null($job->getKey());
    $add  = is_null($job->getKey());
?>



<?php $__env->startSection('content'); ?>
    <div class="dashboard-container container">


        <!-- Dashboard Content
        ================================================== -->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner">
                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <div class="d-flex justify-content-between new-condidate-title">
                        <h3>Post a Job</h3>
                        <p>
                            <a href="#">Cancel</a>
                        </p>
                    </div>
                </div>
                <!-- Row -->
                <div class="row">
                    <form
                        action="<?php echo e($edit ? route('voyager.jobs.update', $job->getKey()) : route('voyager.jobs.store')); ?>"
                        method="POST" enctype="multipart/form-data">
                        <!-- PUT Method if we are editing -->
                    <?php if($edit): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <!-- Dashboard Box -->
                        <div class="col-xl-12">
                            <div class="dashboard-box margin-top-0">

                                <!-- Headline -->
                                <div class="headline">
                                    <h3>Details</h3>
                                </div>

                                <div class="content with-padding padding-bottom-10">
                                    <div class="row">

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Job Title</h5>
                                                <input type="text" class="with-border" name="name"
                                                       value="<?php echo e($job->name); ?>">
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Job Type</h5>
                                                <select
                                                    class="selectpicker with-border" data-size="7" title="Select Category" name="type_id">
                                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($type->id); ?>" <?php if($job->type_id == $type->id): ?> selected="selected" <?php endif; ?>><?php echo e($type->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Hiring Manaer</h5>
                                                <input type="text" class="with-border">
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>
                                                    Location
                                                    <i class="icon-material-outline-location-on"></i>
                                                </h5>
                                                <div class="input-with-icon">
                                                    <div id="autocomplete-container">
                                                        <input id="autocomplete-input" class="with-border" type="text"
                                                               name="location" value="<?php echo e($job->location); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Salary</h5>
                                                <div class="row">
                                                    <div class="col-xl-6">
                                                        <div class="input-with-icon">
                                                            <input class="with-border" type="text" placeholder="Min"
                                                                   name="start_range"
                                                                   value="<?php echo e($job->start_range); ?>">
                                                            <i class="currency">USD</i>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-6">
                                                        <div class="input-with-icon">
                                                            <input class="with-border" type="text" placeholder="Max"
                                                                   name="end_range"
                                                                   value="<?php echo e($job->end_range); ?>">
                                                            <i class="currency">USD</i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Tags <span>(optional)</span>
                                                    <!--											<i class="help-icon" data-tippy-placement="right" title="Maximum of 10 tags"></i>-->
                                                </h5>
                                                <div class="keywords-container">
                                                    <div class="keyword-input-container">
                                                        <select class="form-control select2 keyword-input with-border" name="tags[]" multiple>
                                                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($tag->id); ?>" <?php if(in_array($tag->id, $job->tags->pluck('id')->toArray())): ?> selected="selected" <?php endif; ?>><?php echo e($tag->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <button id="multipleSelectExample" class="keyword-input-button-1 ripple-effect"><i class="icon-material-outline-add"></i></button>
                                                    </div>
                                                    <div class="keywords-list"><!-- keywords go here --></div>
                                                    <div class="clearfix"></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Viewer</h5>
                                                <select name="viewers[]" id="" multiple>
                                                    <?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viewer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($viewer->id); ?>"  <?php if(in_array($viewer->id, $job->viewers->pluck('id')->toArray())): ?> selected <?php endif; ?> ><?php echo e($viewer->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-xl-12">
                                            <div class="submit-field">
                                                <h5>Job Description</h5>
                                                <textarea cols="30" rows="5" class="with-border"
                                                          name="description"><?php echo e($job->description); ?></textarea>
                                            </div>
                                        </div>


                                        <div class="uploadButton col-xl-12 margin-top-30">
                                            <?php if($job->images && json_decode($job->images)): ?>
                                                <div>
                                                    <?php $__currentLoopData = json_decode($job->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="img_settings_container" style="float:left;padding-right:15px;">
                                                            <a href="#" class="voyager-x remove-multi-image" style="position: absolute;"></a>
                                                            <img src="<?php echo e(\Voyager::image( $image )); ?>"   style="max-width:200px; height:auto; clear:both; display:block; padding:2px; border:1px solid #ddd; margin-bottom:5px;">
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            <?php endif; ?>
                                            <br>
                                            <div class="clearfix"></div>
                                            <input id="upload" class="uploadButton-input" type="file" name="images[]" multiple="multiple" accept="image/*" />
                                            <label class="uploadButton-button ripple-effect" for="upload">Upload
                                                Files</label>

                                        </div>



                                        <div class="col-xl-6 justify-content-end d-flex">
                                            <button type="submit" class="button ripple-effect big margin-top-30">Add
                                                Role
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>


                </div>
                <!-- Row / End -->

                <!-- Footer -->
                <div class="dashboard-footer-spacer"></div>
                <div class="small-footer margin-top-15">


                    <div class="clearfix"></div>
                </div>
                <!-- Footer / End -->

            </div>
        </div>
        <!-- Dashboard Content / End -->

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function () {
            $('.select2').select2();

            $("#multipleSelectExample").click(function () {
                $(".select2").select2("open");
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/jobs/edit-add.blade.php ENDPATH**/ ?>