<!doctype html>
<html lang="en">
<head>

    <!-- Basic Page Needs
    ================================================== -->
    <title>Recruiting Tool</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/colors/blue.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/rec_style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/rec_index.css')); ?>">


    <style>
        .blink {
            animation: blink 0.7s infinite;
        }
        @keyframes  blink{
            to { opacity: .0; }
        }

        .header-sub-title {
            padding: 0.1em;
            font-size: 48px;
            line-height: 45px;
            font-style: normal;
            font-weight: 400;
            color: #000000;
            margin-bottom: 50px;
        }
    </style>

</head>
<body>
<div id="wrapper">

    <!-- Header Container
    ============================= ===================== -->
    <header id="header-container"  >

        <!-- Header -->
        <div id="header" class="">
            <div class="container">

                <!-- Left Side Content -->
                <div class="left-side">

                    <!-- Logo -->
                    <div class="tool_logo">
                        <a href="index.html"><img src="images/rec_index_img/tool-logo.png" alt=""></a>
                    </div>


                    <div class="clearfix"></div>
                    <!-- Main Navigation / End -->

                </div>
                <!-- Left Side Content / End -->


                <!-- Right Side Content / End -->
                <div class="right-side">

                    <div id="navigation">
                        <ul id="responsive">
                            <li>
                                <a href="#">Pricing</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('voyager.login')); ?>">Login</a>
                            </li>
                            <li>
                                <a class="sing-up" href="#">Sign Up</a>
                            </li>
                        </ul>
                    </div>

                    <!-- Mobile Navigation Button -->
                    <span class="mmenu-trigger">
					<button class="hamburger hamburger--collapse" type="button">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</button>
				</span>

                </div>
                <!-- Right Side Content / End -->

            </div>
        </div>
        <!-- Header / End -->

    </header>
    <div class="clearfix"></div>
    <!-- Header Container / End -->


</div>


<?php echo $__env->yieldContent('content'); ?>



<!-- Scripts
================================================== -->
<script src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-migrate-3.1.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/mmenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/tippy.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-slider.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/snackbar.js')); ?>"></script>
<script src="<?php echo e(asset('js/clipboard.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
<script>
    // Snackbar for user status switcher
    $('#snackbar-user-status label').click(function() {
        Snackbar.show({
            text: 'Your status has been changed!',
            pos: 'bottom-center',
            showAction: false,
            actionText: "Dismiss",
            duration: 3000,
            textColor: '#fff',
            backgroundColor: '#383838'
        });
    });
</script>
<script>
    function initAutocomplete() {
        var options = {
            types: ['(cities)'],
            // componentRestrictions: {country: "us"}
        };

        var input = document.getElementById('autocomplete-input');
        var autocomplete = new google.maps.places.Autocomplete(input, options);
    }

    // Autocomplete adjustment for homepage
    if ($('.intro-banner-search-form')[0]) {
        setTimeout(function(){
            $(".pac-container").prependTo(".intro-search-field.with-autocomplete");
        }, 300);
    }

</script>
<script src="https://maps.googleapis.com/maps/api/js?key=&libraries=places&callback=initAutocomplete"></script>
<script>
    const words = ["simple", "smart", "easy", "powerful"];
    let i = 0;
    let timer;

    function typingEffect() {
        let word = words[i].split("");
        var loopTyping = function() {
            if (word.length > 0) {
                document.getElementById('word').innerHTML += word.shift();
            } else {
                deletingEffect();
                return false;
            };
            timer = setTimeout(loopTyping, 400);
        };
        loopTyping();
    };

    function deletingEffect() {
        let word = words[i].split("");
        var loopDeleting = function() {
            if (word.length > 0) {
                word.pop();
                document.getElementById('word').innerHTML = word.join("");
            } else {
                if (words.length > (i + 1)) {
                    i++;
                } else {
                    i = 0;
                };
                typingEffect();
                return false;
            };
            timer = setTimeout(loopDeleting, 200);
        };
        loopDeleting();
    };

    typingEffect();
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\recruiting\resources\views/layout.blade.php ENDPATH**/ ?>