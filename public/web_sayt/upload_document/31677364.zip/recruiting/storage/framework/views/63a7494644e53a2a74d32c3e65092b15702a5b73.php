<?php $__env->startSection('content'); ?>

<!-- Wrapper -->

    <div class="single-page-header" style="background: #F7F7F7;">
        <div class="d-flex justify-content-between align-items-center" style="position: relative; z-index: 111; margin-bottom: 50px; padding: 0 50px">
            <div>
                 <a href="<?php echo e(url()->previous()); ?>">
                    <img src="<?php echo e(asset('images/rec_images/Arrow%20-%20Left.png')); ?>" alt="" width="24" height="24">
                </a>
            </div>
            <div class="d-flex justify-content-between">
                <p class="prof-rating-text">
                    Priority Hire
                </p>
                <div class="prof-star-rating">
                    <div class="star-rating">
                        <span class="star"></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <div class="single-page-header-inner">
                        <div class="left-side">
                            <div class="profile-img"><a href="single-company-profile.html"><img src="<?php echo e(\Voyager::image($candidate->images)); ?>" alt=""></a></div>
                            <div class="header-details">
                                <h3><?php echo e($candidate->name); ?></h3>
                                <h5>Front-End Developer</h5>
                                <ul>
                                    <li><div class="star-rating" data-rating="4.9"></div></li>
                                    <li>Location<br><i
                                            class="icon-material-outline-location-on"></i><?php echo e($candidate->location); ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Page Content
    ================================================== -->
    <div class="container">
        <div class="row">

            <!-- Content -->
            <div class="col-xl-8 col-lg-8 content-right-offset">
                <ul class="tab-prof nav nav-tabs d-flex">
                    <li style="list-style: none" class="active"><a  class="tab-activ-sidebar-block" data-toggle="tab" href="#home">Resume</a></li>
                    <li style="list-style: none"><a class="tab-activ-sidebar-block" data-toggle="tab" href="#menu1">Notes</a></li>
                    <li style="list-style: none"><a class="tab-activ-sidebar-none" data-toggle="tab" href="#menu2">Applications</a></li>
                </ul>

                <div class="tab-content">
                    <div id="home" class="tab-pane fade in active">
                        <h3>About</h3>
                        <p>
                           <?php echo e($candidate->about); ?>

                        </p>
                        <div>
                            <div class="title-employe">
                                <h3>Employment History <span class="rename-title"></span></h3>

                            </div>
                             <?php $__currentLoopData = $candidate->histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="text-employe">
                                <h3><?php echo e($history->title); ?></h3>
                                <p><?php echo e($history->company); ?> <span> <?php echo e($history->start_date); ?> - <?php echo e($history->end_date); ?></span></p>
                                <p><?php echo e($history->description); ?></p>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Sidebar -->
            <div class="col-xl-4 col-lg-4">
                <div class="sidebar-container">

                    <a href="#small-dialog" class="apply-now-button popup-with-zoom-anim">Add Note
                        <!--                        <i class="icon-material-outline-arrow-right-alt"></i>-->
                    </a>
                    <a href="<?php echo e(route('voyager.messages.index')); ?>" class="message-button">Message

                    </a>
                    <a href="#" class="message-button">Schedule

                    </a>
                    <div class="widget-none">
                        <!-- Sidebar Widget -->
                        <div class="sidebar-widget">
                            <div class="selary-expectations">

                                <div>
                                    <h4><?php echo e($candidate->start_range); ?> USD</h4>
                                    <p>Salary Expectations</p>

                                </div>

                                <div>
                                    <img src="<?php echo e(asset('images/rec_images/Edit-after.png')); ?>" alt="">
                                </div>
                            </div>


                        </div>
                        <!-- Sidebar Widget -->
                        <div class="sidebar-widget">
                            <div class="social-profiles">
                                <h3>Social Profiles</h3>
                                <div>
                                <p><?php echo e($candidate->linkdin); ?></p>
                                    <div class="plus-skills">
                                        <img src="a<?php echo e(asset('images/rec_images/Plus-after.png')); ?>" alt="">
                                    </div>
                                </div>
                            </div>


                        </div>
                        <div class="sidebar-widget">
                            <h3>Skills</h3>

                            <div class="skills-prof tags-container">
                                <?php $__currentLoopData = $candidate->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tag">
                                    <input type="checkbox" id="tag1"/>
                                    <label for="tag1"><?php echo e($skill->name); ?></label>
                                    <span class="dellet"></span>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="tag plus-skills">
                                    <img src="<?php echo e(asset('images/rec_images/Plus-after.png')); ?>" alt="">
                                </div>

                            </div>

                            <div class="clearfix"></div>
                        </div>


                        <div class="sidebar-widget">
                            <div class="prof-attachments">
                                <div class="d-flex justify-content-between">
                                    <h3>Attachments</h3>
                                    <div class="plus-skills">
                                        <img src="images/rec_images/Plus-after.png" alt="">
                                    </div>
                                </div>
                                <div class="attachment-count d-flex justify-content-between">
                                    <?php if($candidate->files && json_decode($candidate->files)): ?>
                                        <?php $__currentLoopData = json_decode($candidate->files); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div>
                                                    <p> <a class="fileType" target="_blank"
                                                           href="<?php echo e(Storage::disk(config('voyager.storage.disk'))->url($file->download_link) ?: ''); ?>">
                                                            <?php echo e($file->original_name ?: ''); ?>

                                                        </a></p>
                                                    <span><?php echo e(preg_replace('/.*\./','',strtoupper($file->original_name))); ?></span>
                                                    <span class="dellet"></span>
                                                </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>







                                </div>

                            </div>

                        </div>
                        <!-- Sidebar Widget -->
                        <div class="sidebar-widget">
                            <h3>Share</h3>
                            <!-- Copy URL -->
                            <div class="copy-url">
                                <input id="copy-url" type="text" value="<?php echo e($candidate->email); ?>" class="with-border" placeholder="">
                                <button class="copy-url-button ripple-effect"
                                        data-clipboard-target="#copy-url"
                                        title="Copy to Clipboard"
                                        data-tippy-placement="top">
                                    <i class="icon-material-outline-file-copy"></i>
                                </button>
                            </div>

                        </div>
                    </div>
                    <div class="widget-block sidebar-widget">
                        <div class="submit-field">
                            <h3>Search Roles to Add</h3>
                            <select class="with-border"  title="ABC-123">
                                <option>ABC-123</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<!-- Snackbar // documentation: https://www.polonel.com/snackbar/ -->
<script>
    $(".tab-activ-sidebar-none").click(function () {
        $(".widget-none").css('display', 'none');
        $(".widget-block").css('display', 'block');
    })
    $(".tab-activ-sidebar-block").click(function () {
        $(".widget-none").css('display', 'block');
        $(".widget-block").css('display', 'none');
    })
</script>

<script>
    // Snackbar for user status switcher
    $('#snackbar-user-status label').click(function() {
        Snackbar.show({
            text: 'Your status has been changed!',
            pos: 'bottom-center',
            showAction: false,
            actionText: "Dismiss",
            duration: 3000,
            textColor: '#fff',
            backgroundColor: '#383838'
        });
    });

    // Snackbar for copy to clipboard button
    $('.copy-url-button').click(function() {
        Snackbar.show({
            text: 'Copied to clipboard!',
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/candidates/profile.blade.php ENDPATH**/ ?>