<?php
    $edit = !is_null($dataTypeContent->getKey());
    $add  = is_null($dataTypeContent->getKey());
?>



<?php $__env->startSection('content'); ?>
    <div class="dashboard-container container">


        <!-- Dashboard Content
        ================================================== -->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner">
                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <div class="d-flex justify-content-between new-condidate-title">
                        <h3>Post a <?php echo e($dataType->display_name_singular); ?></h3>
                        <p>
                            <a href="#">Cancel</a>
                        </p>
                    </div>
                </div>
                <!-- Row -->
                <div class="row">
                    <form
                        action="<?php echo e($edit ? route('voyager.'.$dataType->slug.'.update', $dataTypeContent->getKey()) : route('voyager.'.$dataType->slug.'.store')); ?>"
                        method="POST" enctype="multipart/form-data">
                        <!-- PUT Method if we are editing -->
                    <?php if($edit): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <!-- Dashboard Box -->
                        <div class="col-xl-12">
                            <div class="dashboard-box margin-top-0">

                                <!-- Headline -->
                                <div class="headline">
                                    <h3>Details</h3>
                                </div>

                                <div class="content with-padding padding-bottom-10">
                                    <div class="row">

                                        <div class="col-xl-12">
                                            <div class="submit-field">
                                                <h5>Title</h5>
                                                <input type="text" class="with-border" name="name"
                                                       value="<?php echo e($dataTypeContent->name); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xl-12 justify-content-end d-flex">
                                            <button type="submit" class="button ripple-effect big margin-top-30">Add
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>


                </div>
                <!-- Row / End -->

                <!-- Footer -->
                <div class="dashboard-footer-spacer"></div>
                <div class="small-footer margin-top-15">


                    <div class="clearfix"></div>
                </div>
                <!-- Footer / End -->

            </div>
        </div>
        <!-- Dashboard Content / End -->

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/sections/edit-add.blade.php ENDPATH**/ ?>