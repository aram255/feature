<?php $__env->startSection('content'); ?>
    <div class="dashboard-container">
        <!--sitebar	-->
        <?php echo $__env->make('voyager::dashboard.sidebar_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--sitebar	-->
        <!--	-->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner" >
                <!-- Dashboard Headline -->
                <div class="row ">
                    <div class="col-xl-12">
                        <div class="d-flex justify-content-between">
                            <h3> Team</h3>
                            <p class="text-team">Upgrade to add 5 more members</p>
                        </div>
                        <div class="dashboard-box">
                            <!-- Headline -->
                            <div class="headline">
                                <h3>4 Team Accounts Remaining</h3>
                            </div>
                            <div class="content">
                                <ul class="dashboard-box-list">
                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <!-- Overview -->
                                            <div class="freelancer-overview">
                                                <div class="freelancer-overview-inner">
                                                    <!-- Avatar -->
                                                    <div class="freelancer-avatar">
                                                        <!--                                                    <div class="verified-badge"></div>-->
                                                        <a href="#"><img src="<?php echo e(\Voyager::image($member->avatar)); ?>" alt=""></a>
                                                    </div>
                                                    <!-- Name -->
                                                    <div class="freelancer-name col-xl-3">
                                                        <lable>Email</lable>
                                                        <input type="email" value="<?php echo e($member->email); ?>" >
                                                    </div>
                                                    <div class="freelancer-name col-xl-3">
                                                        <lable>Access</lable>
                                                        <select name="" >
                                                            <option value="Team Member">Team Member</option>
                                                            <option value="Viewer">Viewer</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Buttons -->
                                            <div class="buttons-to-right">
                                                <a href="#" class="button red ripple-effect ico" title="Remove" data-tippy-placement="left">
                                                    <i class="icon-feather-trash-2"></i>
                                                    Remove
                                                </a>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <div class="team-btn">
                            <a href="<?php echo e(route('voyager.users.create')); ?>">Add New</a>
                        </div>
                    </div>
                </div>
                <div class="dashboard-footer-spacer"></div>
            </div>
        </div>
        <!-- -->
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/team/list.blade.php ENDPATH**/ ?>