<div class="modal fade" id="modal-id">
<div class="modal-dialog">
    <div class="modal-content">

        <div class="modal-header">
            <h4 class="modal-title" id="userCrudModal"></h4>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>

        <div class="modal-body">
            <form id="companydata">

                <input type="hidden" id="company_id" name="company_id" value="">
                <input type="text" id="title" name="name" value="">
                <input type="date" id="start_date" name="start_date" value="">
                <input type="date" id="end_date" name="end_date" value="">
                </label><br>

                <input type="submit" value="Submit" id="submit" class="btn btn-sm btn-outline-danger py-0" style="font-size: 0.8em;">

            </form>
        </div>

    </div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/events/modal.blade.php ENDPATH**/ ?>