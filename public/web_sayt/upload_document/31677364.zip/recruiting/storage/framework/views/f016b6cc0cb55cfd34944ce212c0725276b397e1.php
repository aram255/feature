
<?php if($get == 'saved'): ?>
    <table class="messenger-list-item m-li-divider <?php if('user_'.Auth::user()->id == $id && $id != "0"): ?> m-list-active <?php endif; ?>">
        <tbody>
        <tr data-action="0" class="<?php if('user_'.Auth::user()->id == $id && $id != "0"): ?> active-message <?php endif; ?>">
            
            <td>
                <div class="avatar av-m" style="background-color: #d9efff; text-align: center;">
                    <svg class="svg-inline--fa fa-bookmark fa-w-12"
                         style="font-size: 22px; color: #68a5ff; margin-top: calc(50% - 10px);"
                         aria-hidden="true" focusable="false" data-prefix="far" data-icon="bookmark"
                         role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"
                         data-fa-i2svg="">
                        <path fill="currentColor"
                              d="M336 0H48C21.49 0 0 21.49 0 48v464l192-112 192 112V48c0-26.51-21.49-48-48-48zm0 428.43l-144-84-144 84V54a6 6 0 0 1 6-6h276c3.314 0 6 2.683 6 5.996V428.43z"></path>
                    </svg>
                    <!-- <span class="far fa-bookmark" style="font-size: 22px; color: #68a5ff; margin-top: calc(50% - 10px);"></span> -->
                </div>
            </td>
            
            <td>
                <p data-id="<?php echo e('user_'.Auth::user()->id); ?>">Saved Messages <span>You</span></p>
                <span>Save messages secretly</span>
            </td>
        </tr>
        </tbody>
    </table>
<?php endif; ?>


<?php if($get == 'users'): ?>
    <table class="messenger-list-item <?php if($user->id == $id && $id != "0"): ?> m-list-active <?php endif; ?>" data-contact="<?php echo e($user->id); ?>">
        <tbody>
        <tr data-action="0">
            
            <td style="position: relative">
                <?php if($user->active_status): ?>
                    <span class="activeStatus"></span>
                <?php endif; ?>
                <div class="avatar av-m"
                     style="background-image: url('<?php echo e(voyager_asset(\Voyager::image($user->avatar))); ?>');">
                </div>
            </td>
            
            <td>
                <p data-id="<?php echo e($type.'_'.$user->id); ?>">
                    <?php echo e(strlen($user->name) > 12 ? trim(substr($user->name,0,12)).'..' : $user->name); ?>

                    <span><?php echo e($lastMessage->created_at->diffForHumans()); ?></span></p>
                <span>
            
                    <?php echo $lastMessage->from_id == Auth::user()->id
                        ? '<span class="lastMessageIndicator">You :</span>'
                        : ''; ?>

                    
                    <?php if($lastMessage->attachment == null): ?>
                        <?php echo e(strlen($lastMessage->body) > 30
                            ? trim(substr($lastMessage->body, 0, 30)).'..'
                            : $lastMessage->body); ?>

                    <?php else: ?>
                        <span class="fas fa-file"></span> Attachment
                    <?php endif; ?>
        </span>
                
                <?php echo $unseenCounter > 0 ? "<b>".$unseenCounter."</b>" : ''; ?>

            </td>

        </tr>
        </tbody>
    </table>
<?php endif; ?>


<?php if($get == 'search_item'): ?>
    <table class="messenger-list-item" data-contact="<?php echo e($user->id); ?>">
        <tr data-action="0">
            
            <td>
                <div class="avatar av-m"
                     style="background-image: url('<?php echo e(asset('/storage/'.config('chatify.user_avatar.folder').'/'.$user->avatar)); ?>');">
                </div>
            </td>
            
            <td>
                <p data-id="<?php echo e($type.'_'.$user->id); ?>">
                <?php echo e(strlen($user->name) > 12 ? trim(substr($user->name,0,12)).'..' : $user->name); ?>

            </td>

        </tr>
    </table>
<?php endif; ?>


<?php if($get == 'sharedPhoto'): ?>
    <div class="shared-photo chat-image" style="background-image: url('<?php echo e($image); ?>')"></div>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/Chatify/layouts/listItem.blade.php ENDPATH**/ ?>