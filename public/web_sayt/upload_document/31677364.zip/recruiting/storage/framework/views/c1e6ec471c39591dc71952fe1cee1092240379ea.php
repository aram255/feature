
<?php if($viewType == 'default'): ?>
    <?php if($from_id != $to_id): ?>
    <div class="message-card" data-id="<?php echo e($id); ?>">
        <div class="message-avatar-img">
            <img src="" alt="">
        </div>
        <p><?php echo ($message == null && $attachment != null && @$attachment[2] != 'file') ? $attachment[1] : nl2br($message); ?>

            <sub title="<?php echo e($fullTime); ?>"><?php echo e($time); ?></sub>
            
            <?php if(@$attachment[2] == 'file'): ?>
            <a href="<?php echo e(route(config('chatify.attachments.route'),['fileName'=>$attachment[0]])); ?>" style="color: #595959;" class="file-download">
                <span class="fas fa-file"></span> <?php echo e($attachment[1]); ?></a>
            <?php endif; ?>
        </p>
    </div>
    
    <?php if(@$attachment[2] == 'image'): ?>
    <div>
        <div class="message-card">
            <div class="image-file chat-image" style="width: 250px; height: 150px;background-image: url('<?php echo e(asset('storage/'.config('chatify.attachments.folder').'/'.$attachment[0])); ?>')">
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>


<?php if($viewType == 'sender'): ?>
    <div class="message-card mc-sender" data-id="<?php echo e($id); ?>">
        <div class="message-avatar-img">
            <img src="" alt="">
        </div>
        <p><?php echo ($message == null && $attachment != null && @$attachment[2] != 'file') ? $attachment[1] : nl2br($message); ?>

            <sub title="<?php echo e($fullTime); ?>" class="message-time">
                <svg class="svg-inline--fa fa-check-double fa-w-16 seen" aria-hidden="true"
                     focusable="false" data-prefix="fas" data-icon="check-double" role="img"
                     xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                    <path fill="currentColor"
                          d="M505 174.8l-39.6-39.6c-9.4-9.4-24.6-9.4-33.9 0L192 374.7 80.6 263.2c-9.4-9.4-24.6-9.4-33.9 0L7 302.9c-9.4 9.4-9.4 24.6 0 34L175 505c9.4 9.4 24.6 9.4 33.9 0l296-296.2c9.4-9.5 9.4-24.7.1-34zm-324.3 106c6.2 6.3 16.4 6.3 22.6 0l208-208.2c6.2-6.3 6.2-16.4 0-22.6L366.1 4.7c-6.2-6.3-16.4-6.3-22.6 0L192 156.2l-55.4-55.5c-6.2-6.3-16.4-6.3-22.6 0L68.7 146c-6.2 6.3-6.2 16.4 0 22.6l112 112.2z"></path>
                </svg>
                 <?php echo e($time); ?></sub>





            <?php if(@$attachment[2] == 'file'): ?>
            <a href="<?php echo e(route(config('chatify.attachments.route'),['fileName'=>$attachment[0]])); ?>" class="file-download">
                <span class="fas fa-file"></span> <?php echo e($attachment[1]); ?></a>
            <?php endif; ?>
        </p>
    </div>
    
    <?php if(@$attachment[2] == 'image'): ?>
    <div>
        <div class="message-card mc-sender">
            <div class="image-file chat-image" style="width: 250px; height: 150px;background-image: url('<?php echo e(asset('storage/'.config('chatify.attachments.folder').'/'.$attachment[0])); ?>')">
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/Chatify/layouts/messageCard.blade.php ENDPATH**/ ?>