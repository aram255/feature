

<?php $__env->startSection('content'); ?>
    <div class="roles-grid condidate-list-grid">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-4">
                    <?php echo $__env->make('voyager::dashboard.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>


                <div class="col-xl-9 col-lg-8 content-left-offset">

                    <h3 class="page-title">Search Candidates</h3>

                    <div class="input-with-icon search-roles margin-top-16 margin-bottom-52">
                        <div id="autocomplete-container">
                            <input id="autocomplete-input" type="text" placeholder="Name, email, tags">
                        </div>
                        <i class="icon-material-outline-search"></i>
                    </div>

                    <div class="d-flex justify-content-between p-0">
                        <div class="sort-by">
                            <span>Sort by:</span>
                            <select class="selectpicker hide-tick">
                                <option>Relevance</option>
                                <option>Newest</option>
                                <option>Oldest</option>
                                <option>Random</option>
                            </select>
                        </div>

                        <div class="grid-list d-flex">
                            <div class="grid d-flex"><i class="grid-icon"></i>
                                <p>Grid</p></div>
                            <div class="list d-flex"><i class="list-icon"></i>
                                <p>List</p></div>
                        </div>
                    </div>

                    <div class="listings-container grid-layout margin-top-16" id="candidate-grid">

                        <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="job-listing">
                                <div class="condidate-list-grid-link">
                                    <div class="applicants">
                                        <?php if(!$data->priority): ?>
                                        <p>
                                        <form method="POST" action="<?php echo e(route('voyager.candidates.priority', $data->getKey())); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <button type="submit">Priority Hire</button>
                                        </form>
                                        </p>
                                        <?php endif; ?>
                                    </div>
                                    <!-- Job Listing Details -->
                                    <!-- Logo -->
                                    <div class="canditate-listing-company-logo">
                                        <img src="images/rec_images/list-grid-img.png" alt="">
                                    </div>
                                    <div class="condidate-listing-details">
                                        <!-- Details -->
                                        <div>
                                            <h3 class="job-listing-title"><?php echo e($data->name); ?> <img
                                                    src="images/rec_images/country.png" alt=""></h3>
                                            <h4 class="job-listing-company">Front-End Developer</h4>
                                            <div class="star-rating" data-rating="4.9">
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Job Listing Footer -->
                                </div>
                                <div class="condidate-listing-footer">
                                    <ul class="d-flex justify-content-between">
                                        <li>Location<br><i
                                                class="icon-material-outline-location-on"></i><?php echo e($data->location); ?></li>
                                        <div>
                                            <li class="icon-rel"><i
                                                    class="icon-material-outline-business-center"></i> <?php echo e($data->phone); ?>

                                            </li>
                                            <li class="icon-rel"><i
                                                    class="icon-material-outline-account-balance-wallet"></i>
                                                <?php echo e($data->email); ?>

                                            </li>
                                        </div>
                                    </ul>
                                    <a href="condidate-profile.html">
                                        <button>
                                            View Profile
                                        </button>
                                    </a>
                                    <a href="<?php echo e(route('voyager.candidates.edit', $data->getKey())); ?>">
                                        Edit profile
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>

                    <div class="listings-container grid-layout margin-top-16" id="candidate-list">

                        <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="job-listing">
                                <div class="condidate-list-grid-link">
                                    <div class="applicants d-flex justify-content-between">
                                        <?php if(!$data->priority): ?>
                                            <p>
                                            <form method="POST" action="<?php echo e(route('voyager.candidates.priority', $data->getKey())); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <button type="submit">Priority Hire</button>
                                            </form>
                                            </p>
                                        <?php endif; ?>
                                        <div class="location-list">
                                            Location<br><i
                                                class="icon-material-outline-location-on"></i><span><?php echo e($data->locaton); ?></span>
                                        </div>
                                    </div>
                                    <div class="job-listing-details">
                                        <div class="d-flex justify-content-between flex-wrap listing-info">
                                            <!-- Logo -->
                                            <div class="canditate-listing-company-logo">
                                                <img src="images/rec_images/list-grid-img.png" alt="">
                                            </div>

                                            <!-- Details -->
                                            <div class="job-listing-description">
                                                <h3 class="job-listing-title"><?php echo e($data->name); ?> <img
                                                        src="images/rec_images/country.png" alt=""></h3>
                                                <h4 class="job-listing-company">Front-End Developer</h4>
                                                <div class="star-rating" data-rating="4.9">

                                                </div>

                                            </div>
                                            <div class="location-list">
                                                <p class="icon-rel"><i
                                                        class="icon-material-outline-business-center"></i>
                                                    <?php echo e($data->phone); ?></p>
                                                <p class="icon-rel"><i
                                                        class="icon-material-outline-account-balance-wallet"></i>
                                                    <?php echo e($data->email); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Job Listing Footer -->
                                <div class="condidate-listing-footer">
                                    <a href="<?php echo e(route('voyager.candidates.profile', $data->getKey())); ?>">
                                        <button>
                                            View Profile
                                        </button>
                                    </a>
                                    <a href="<?php echo e(route('voyager.candidates.edit', $data->getKey())); ?>">
                                        Edit profile
                                    </a>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>

                    <!-- Pagination -->
                    <div class="clearfix"></div>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo e($candidates->links("pagination::custom")); ?>


                        </div>
                    </div>
                    <!-- Pagination / End -->

                </div>
            </div>
            <div class="dashboard-footer-spacer"></div>

            <div class="clearfix"></div>
            <!-- Footer / End -->
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        $(".grid").click(function () {
            $("#candidate-grid").css('display', 'flex');
            $("#candidate-list").css('display', 'none');
            $(".grid").css('color', '#2A41E8');
            $(".list").css('color', '#666666');
        })
        $(".list").click(function () {
            $("#candidate-grid").css('display', 'none');
            $("#candidate-list").css('display', 'flex');
            $(".list").css('color', '#2A41E8');
            $(".grid").css('color', '#666666');
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/candidates/browse.blade.php ENDPATH**/ ?>