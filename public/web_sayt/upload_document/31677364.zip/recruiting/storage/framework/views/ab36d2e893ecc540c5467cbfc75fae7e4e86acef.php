<?php $request = app('Illuminate\Http\Request'); ?>

<?php
$checkboxs = collect($request->all())->filter(function ($item, $key){
    return preg_match('/\_/', $key) && $item == 'on';
})->toArray();
?>
<div class="sidebar-container">
    <form action="" id="filter-form">
        <!-- Location -->
        <div class="sidebar-widget">
            <h3>Location</h3>
            <div class="input-with-icon">
                <div id="autocomplete-container">
                    <input id="autocomplete-input" type="text" placeholder="Location" name="location"
                           value="<?php echo e($request->get('location')); ?>">
                </div>
                <i class="icon-material-outline-location-on"></i>
            </div>
        </div>

        <!-- Keywords -->
        <div class="sidebar-widget">
            <h3>Keywords</h3>
            <div class="keywords-container">
                <div class="keyword-input-container">
                    <input type="text" class="keyword-input" placeholder="e.g. job title" name="title"
                           value="<?php echo e($request->get('title')); ?>"/>
                    <button class="keyword-input-button ripple-effect"><i class="icon-material-outline-add"></i>
                    </button>
                </div>
                <div class="keywords-list"><!-- keywords go here --></div>
                <div class="clearfix"></div>
            </div>
        </div>

        <!-- Category -->
        <div class="sidebar-widget">
            <h3>Category</h3>
            <?php if(isset($ranges)): ?>
                <select class="selectpicker default select-filter" multiple data-selected-text-format="count"
                        data-size="7" title="All Categories" name="range">
                    <?php $__currentLoopData = $ranges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($range->id); ?>"
                                <?php if($range->id == $request->get('range')): ?> selected="selected" <?php endif; ?>><?php echo e($range->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php endif; ?>
        </div>

        <!-- Job Types -->
        <div class="sidebar-widget">
            <h3>Job Type</h3>
            <div class="switches-list">
                <?php if(isset($types)): ?>
                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="switch-container">
                            <label class="switch checkbox-filter">
                                <input class="checkbox-filter"
                                             name="type_<?php echo e($type->id); ?>"
                                             type="checkbox"
                                             <?php if(array_key_exists('type_'.$type->id, $checkboxs)): ?> checked="checked" <?php endif; ?>
                                ><span
                                    class="switch-button"></span> <?php echo e($type->name); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <!-- Salary -->
        <div class="sidebar-widget">
            <h3>Salary</h3>
            <div class="margin-top-55"></div>
            <!-- Range Slider -->
            <input class="range-slider" type="text" value="" data-slider-currency="$" data-slider-min="1500"
                   data-slider-max="15000" data-slider-step="100" data-slider-value="[1500,15000]"/>
        </div>

        <?php if(isset($skills)): ?>
        <div class="sidebar-widget">
            <h3>Skills</h3>
            <div class="tags-container">
                    <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tag checkbox-filter">
                            <input type="checkbox" id="tag<?php echo e($skill->id); ?>" name="skill_<?php echo e($skill->id); ?>" <?php if(array_key_exists('skill_'.$skill->id, $checkboxs)): ?>  checked="checked" <?php endif; ?> />
                            <label for="tag<?php echo e($skill->id); ?>"><?php echo e($skill->name); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="clearfix"></div>
        </div>
        <?php endif; ?>
        <?php if(isset($tags)): ?>
            <div class="sidebar-widget">
                <h3>Tags</h3>
                <div class="tags-container">
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tag checkbox-filter">
                            <input type="checkbox" id="tag<?php echo e($tag->id); ?>" name="tag_<?php echo e($tag->id); ?>" <?php if(array_key_exists('tag_'.$tag->id, $checkboxs)): ?>  checked="checked" <?php endif; ?> />
                            <label for="tag<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="clearfix"></div>
            </div>
        <?php endif; ?>
    </form>

</div>


<?php $__env->startPush('script'); ?>
    <script>
        $("#autocomplete-input").focusout(function (event) {
            $('#filter-form').submit();
        });
        $('.select-filter').change(function () {
            $('#filter-form').submit();
        });
        $('.checkbox-filter').click(function () {
            $('#filter-form').submit();
        });

        $('.switch').click(function (e){
            if ($(this).children('input').prop("checked"))
                $(this).children('input').attr("checked",'checked');
            else
                $(this).children('input').removeAttr("checked");

        });
        $('.tag').click(function (e){
            if ($(this).children('input').prop("checked"))
                $(this).children('input').attr("checked",'checked');
            else
                $(this).children('input').removeAttr("checked");

        });

    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/dashboard/filter.blade.php ENDPATH**/ ?>