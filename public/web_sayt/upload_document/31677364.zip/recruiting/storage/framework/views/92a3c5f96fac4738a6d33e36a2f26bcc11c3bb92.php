<?php
    $menu = \App\Models\Menu::findOrFail(2);
?>

<nav id="navigation">
    <ul id="responsive">
        <?php $__currentLoopData = $menu->getItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(isset($item['route']) && Route::has($item['route']) ? route($item['route']) : (isset($item['route']) ? $item['route'] : '#')); ?>" class="current"><?php echo e($item->title); ?></a>
                <?php if($item->children->count()): ?>
                    <ul class="dropdown-nav">
                        <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(isset($chItem['route']) && Route::has($chItem['route']) ? route($chItem['route']) : (isset($chItem['route']) ? $chItem['route'] : '#')); ?>"><?php echo e($chItem->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</nav>
<div class="clearfix"></div>
<?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/dashboard/navbar_new.blade.php ENDPATH**/ ?>