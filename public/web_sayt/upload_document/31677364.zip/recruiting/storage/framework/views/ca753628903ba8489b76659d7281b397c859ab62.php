<?php $__env->startSection('content'); ?>

    <div class="dashboard-container">
        <!--sitebar	-->
        <div class="dashboard-sidebar">
            <div class="dashboard-sidebar-inner" data-simplebar>
                <div class="dashboard-nav-container">
                    <a href="#" class="dashboard-responsive-nav-trigger">
					<span class="hamburger hamburger--collapse" >
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</span>
                        <span class="trigger-title">Dashboard Navigation</span>
                    </a>
                    <div class="dashboard-nav">
                        <div class="dashboard-nav-inner">

                            <ul data-submenu-title="">
                                <li class="active"><a href="dashboard.html"><i class="icon-material-outline-dashboard"></i> Dashboard</a></li>
                                <li><a href="dashboard-messages.html"><i class="icon-material-outline-question-answer"></i> Messages <span class="nav-tag">2</span></a></li>
                                <li><a href="dashboard-notes.html"><i class="icon-material-outline-note-add"></i> Notes </a></li>
                            </ul>
                            <ul>
                                <li class="active-submenu">
                                    <a href="#">
                                        <i class="icon-material-outline-star-border"></i>Roles
                                    </a>
                                    <ul>
                                        <li><a href="#">Active</a></li>
                                        <li><a href="new-role.html">New Role</a></li>
                                        <li><a href="#">Archived</a></li>
                                    </ul>
                                </li>
                                <li  class="active-submenu">
                                    <a href="#">
                                        <i class="icon-material-candidates"></i>Candidates
                                    </a>
                                    <ul data-submenu-title="Candidates">
                                        <li><a href="#">All</a></li>
                                        <li><a href="#">New Profile</a></li>
                                        <li><a href="priority-hire.html">Priority Hire</a></li>
                                    </ul>

                                </li>
                                <li  class="active-submenu">
                                    <a href="#">
                                        <i class="icon-material-outline-settings"></i>Account
                                    </a>
                                    <ul data-submenu-title="Account">
                                        <li><a href="dashboard-team.html"> Team </a></li>
                                        <li><a href="dashboard-settings.html"> Settings</a></li>
                                        <li><a href="index-logged-out.html"> Logout</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--sitebar	-->
        <!--	-->

        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner" >

                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <h3>Howdy, Tom!</h3>
                    <span>We are glad to see you again!</span>


                    <!-- Breadcrumbs -->
                    <!--				<nav id="breadcrumbs" class="dark">-->
                    <!--					<ul>-->
                    <!--						<li><a href="#">Home</a></li>-->
                    <!--						<li>Dashboard</li>-->
                    <!--					</ul>-->
                    <!--				</nav>-->
                </div>

                <div class="row">

                    <div class="col-xl-8 dashboard-box">

                        <div class="d-flex justify-content-center preHeader-calendar">
                            <a href="" class="edit_event" style="text-decoration: none" data-toggle="modal" data-target="#exampleModalCenterEditevent" data-tippy-placement="top"></a>

                            <a href="" style="text-decoration: none" data-toggle="modal" class="createEvent" data-target="#exampleModalCenterevent" data-tippy-placement="top">
                                <div class="dashboard-box create" style="min-width: 100px; padding: 10px 30px; text-align: center"><img src="images/rec_images/Calendar.png" style="margin-right: 20px">Create</div>
                            </a>


                        </div>
                        <div id="wrapper">
                            <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js"></script>
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js"></script>
                            <div class="panel-body"> <?php echo $calendar->calendar(); ?> <?php echo $calendar->script(); ?> </div>
                        </div>

                    </div>
                    <div class="col-xl-4">
                        <div  class="pipeline-space">
                            <h3 >Pipelines
                                <img src="images/rec_images/Activity.png" alt="" style="margin-left: 10px" width="20" height="20">
                            </h3>
                            <ul class="list-unstyled">
                                <li>34 Active Roles</li>
                                <li>38 Leeds</li>
                                <li>35 Phone Screens</li>
                                <li>25 Interviewing</li>
                            </ul>
                        </div>
                        <div class="dashboard-box child-box-in-row dashboard-add-note">
                            <div class="headline">
                                <h3><i class="icon-material-outline-note-add-dsh"></i> To-Do</h3>
                            </div>
                            <div class="content with-padding notes">
                                <div class="dashboard-note">
                                    <p>Extend premium plan for next month</p>
                                </div>
                            </div>
                            <div class="add-note-button">
                                <a href="" class=" button full-width button-sliding-icon btn   popup-with-zoom-anim" data-toggle="modal" data-target="#exampleModalCenter">Add Item <i class="icon-material-outline-arrow-right-alt"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade modal-withdraw"  id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered d-flex justify-content-center align-items-center" style="height: 870px;" role="document">
                        <div class="modal-content w-100">
                            <div style="padding: 20px 45px 50px;">
                                <div class="welcome-text">
                                    <h3>New <b>Note</b></h3>
                                </div>
                                <!-- Form -->
                                <form id="apply-now-form"  method="post" action="<?php echo e(url('/admin/addNewNote')); ?>" enctype="multipart/form-data" class="add-to-do">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" class="event" name="event_id">
                                    <p>Details</p>
                                    <div class="input-with-icon-left">
                                        <div class="form-group">
                                            <div>
                                                <textarea name="description" id="user-message" class="form-control" cols="30" rows="10" placeholder=""></textarea>
                                            </div>
                                        </div>
                                        <select id="year" name="priority">
                                            <option value="hide">LOW</option>
                                            <option >MEDIUM</option>
                                            <option >HIGH</option>
                                        </select>
                                    </div>
                                    <div class="withdraw-notes">
                                        <button type="button" class="notes-close btn btn-secondary" data-dismiss="modal">Cancel
                                        </button>
                                        <button type="submit" class="save-event button btn-primary">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Apply for a job popup / End -->

                <!-- Scripts
                ================================================== -->
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js"></script>


                <script>
























                </script>



                <!--<script src="js/jquery-3.4.1.min.js"></script>-->
                <!--<script src="js/jquery-migrate-3.1.0.min.js"></script>-->

                <!-- Apply for a job popup
                ================================================== -->
                <div class="modal fade modal-withdraw"  id="exampleModalCenteredit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered d-flex justify-content-center align-items-center" style="height: 870px;" role="document">
                        <div class="modal-content w-100">
                            <div style="padding: 20px 45px 50px;">
                                <div class="welcome-text">
                                    <h3>Edit <b>Note</b></h3>
                                </div>
                                <!-- Form -->
                                <form method="post" action="<?php echo e(url('admin/updateNote')); ?>" id="note_edit" class="add-to-do" >
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" class="editNote" name="note_id">
                                    <p>Details</p>
                                    <div class="input-with-icon-left">
                                        <div class="form-group">
                                            <div>
                                                <textarea name="description" class="form-control note-description" cols="30" rows="10" placeholder="Meeting with candidate at 3pm who applied for Billingual Event Support Specialist"></textarea>
                                            </div>
                                        </div>
                                        <select name="priority" class="notePriority">
                                            <option value="LOW">LOW</option>
                                            <option value="MEDIUM" selected>MEDIUM</option>
                                            <option value="HIGH">HIGH</option>
                                        </select>
                                    </div>
                                    <div class="withdraw-notes">
                                        <button type="button" class="notes-close btn btn-secondary" data-dismiss="modal">Cancel
                                        </button>
                                        <button type="submit" class="save-event button btn-primary">Save</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade modal-withdraw"  id="exampleModalCenterEditevent" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered d-flex justify-content-center align-items-center" style="height: 870px;" role="document">
                        <div class="modal-content w-100">
                            <div style="padding: 20px 45px 50px;">
                                <div class="welcome-text">
                                    <h3>Edit</h3>
                                </div>
                                <!-- Form -->
                                <form method="post" action="<?php echo e(url('admin/update')); ?>" id="editEvent" class="add-event">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" class="eventEdit" name="event_edit_id">
                                    <p>Event Title</p>
                                    <div class="input-with-icon-left">
                                        <div class="form-group">
                                            <div>
                                                <input type="text" class="editable" name="title">
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <p> <i class="time-circle"></i>

                                            <input type="datetime-local" id="meeting-time"
                                                   name="meeting"
                                                   class="event-date">
                                            <span style="opacity: 0.4"> PST </span></p>
                                    </div>
                                    <div>
                                        <p> <i class="time-circle"></i>

                                            <input type="datetime-local" id="meeting-time-end"
                                                   name="meet"
                                                   class="event-date">
                                            <span style="opacity: 0.4"> PST </span></p>
                                    </div>
                                    <div>
                                        <i class="calling"> </i>
                                        <button class="calling-btn">
                                            Add Google Meet video conferencing
                                        </button>
                                    </div>
                                    <p>Details</p>
                                    <div class="input-with-icon-left">
                                        <div class="form-group">
                                            <div>
                                                <textarea name="user-message"  class="form-control eventDetails" cols="30" rows="5"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <i class="add-user-event"> </i><input class="add-guests" type="text" placeholder="Add guests">

                                    </div>
                                    <div>
                                        <i class="calendar-event"> </i>
                                        <select name="editedType" id="" class="event-select">
                                            <option value="hide">contact</option>Select Event Type
                                            <option>phone</option>
                                            <option>screen</option>
                                            <option>interview</option>
                                            <option>offer call</option>
                                            <option>questions</option>
                                        </select>
                                    </div>
                                    <div class="withdraw-notes">
                                        <button type="button" class="notes-close btn btn-secondary" data-dismiss="modal">Cancel
                                        </button>
                                        <button type="submit" class="save-event button btn-primary">Schedule</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade modal-withdraw"  id="exampleModalCenterevent" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered d-flex justify-content-center align-items-center" style="height: 870px;" role="document">
                        <div class="modal-content w-100">
                            <div style="padding: 20px 45px 50px;">
                                <div class="welcome-text">
                                    <h3>New <b>Event</b></h3>
                                </div>
                                <!-- Form -->
                                <form method="post" action="<?php echo e(url('/admin/addNewEvent')); ?>" class="add-event">
                                    <?php echo e(csrf_field()); ?>

                                    <p>Event Title</p>
                                    <div class="input-with-icon-left">
                                        <div class="form-group">
                                            <div>
                                                <input type="text" name="title">
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <p><i class="time-circle"></i>

                                            <input type="datetime-local" id="meeting"
                                                   name="meeting"
                                                   class="event-date">
                                            <span style="opacity: 0.4"> PST </span></p>
                                    </div>
                                    <div>
                                        <p><i class="time-circle"></i>

                                            <input type="datetime-local" id="meeting-time-end"
                                                   name="meet"
                                                   class="event-date">
                                            <span style="opacity: 0.4"> PST </span></p>
                                    </div>
                                    <div>
                                        <i class="calling"> </i>
                                        <button class="calling-btn">
                                            Add Google Meet video conferencing
                                        </button>
                                    </div>
                                    <p>Details</p>
                                    <div class="input-with-icon-left">
                                        <div class="form-group">
                                            <div>
                                                <textarea name="user_message"  class="form-control" cols="30" rows="5"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <i class="add-user-event"> </i><input class="add-guests" type="text" placeholder="Add guests">
                                    </div>
                                    <div>
                                        <i class="calendar-event"> </i>
                                        <select name="type" id="" class="event-select">
                                            <option value="hide">contact</option>Select Event Type
                                            <option>phone</option>
                                            <option>screen</option>
                                            <option>interview</option>
                                            <option>offer call</option>
                                            <option>questions</option>
                                        </select>
                                    </div>
                                    <div class="withdraw-notes">
                                        <button type="button" class="notes-close btn btn-secondary" data-dismiss="modal">Cancel
                                        </button>
                                        <button type="submit" class="save-event button btn-primary">Schedule</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade modal-withdraw"  id="exampleModalCentereventdel" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered d-flex justify-content-center align-items-center" style="height: 870px;" role="document">
                        <div class="modal-content w-100">
                            <div style="padding: 20px 45px 50px;">
                                <div class="welcome-text-password">
                                    <h3 class="text-center margin-bottom-50"><b>Delete</b> from list?</h3>
                                </div>
                                <form action="<?php echo e(url('admin/remove')); ?>" id="deleteNote" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" class="delNote" name="id">
                                    <div class="withdraw-notes">
                                        <button type="button" class="notes-close btn btn-secondary" data-dismiss="modal">Cancel
                                        </button>
                                        <button type="submit" class="withdraw del btn-primary">Delete Item</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="dashboard-footer-spacer"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/home/dashboard.blade.php ENDPATH**/ ?>
