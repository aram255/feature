


<?php $__env->startPush('head'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="dashboard-container">
        <!--sitebar	-->
        <?php echo $__env->make('voyager::dashboard.sidebar_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--sitebar	-->
        <!--	-->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner" >

                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <h3>Howdy, Tom!</h3>
                    <span>We are glad to see you again!</span>

                </div>

                <div class="row">

                    <div class="col-xl-8 dashboard-box">

                        <div class="d-flex justify-content-center preHeader-calendar">
                            <a href="" class="edit_event" style="text-decoration: none" data-toggle="modal" data-target="#exampleModalCenterEditevent" data-tippy-placement="top"></a>

                            <a href="" style="text-decoration: none" data-toggle="modal" class="createEvent" data-target="#exampleModalCenterevent" data-tippy-placement="top">
                                <div class="dashboard-box create" style="min-width: 100px; padding: 10px 30px; text-align: center"><img src="images/rec_images/Calendar.png" style="margin-right: 20px">Create</div>
                            </a>


                        </div>

                        <div class="panel-body"> <?php echo $calendar->calendar(); ?> <?php echo $calendar->script(); ?> </div>

                    </div>
                    <div class="col-xl-4">
                        <div  class="pipeline-space">
                            <h3 >Pipelines
                                <img src="images/rec_images/Activity.png" alt="" style="margin-left: 10px" width="20" height="20">
                            </h3>
                            <ul class="list-unstyled">
                                <li>34 Active Roles</li>
                                <li>38 Leeds</li>
                                <li>35 Phone Screens</li>
                                <li>25 Interviewing</li>
                            </ul>
                        </div>
                        <div class="dashboard-box child-box-in-row dashboard-add-note">
                            <div class="headline">
                                <h3><i class="icon-material-outline-note-add-dsh"></i> To-Do</h3>
                            </div>
                            <div class="content with-padding notes">
                                <div class="dashboard-note">
                                    <p>Extend premium plan for next month</p>
                                </div>
                            </div>
                            <div class="add-note-button">
                                <a href="" class=" button full-width button-sliding-icon btn   popup-with-zoom-anim" data-toggle="modal" data-target="#exampleModalCenter">Add Item <i class="icon-material-outline-arrow-right-alt"></i></a>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
            <div class="dashboard-footer-spacer"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <div class="modal fade modal-withdraw"  id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered d-flex justify-content-center align-items-center" style="height: 870px;" role="document">
            <div class="modal-content w-100">
                <div style="padding: 20px 45px 50px;">
                    <div class="welcome-text">
                        <h3>New <b>Note</b></h3>
                    </div>
                    <!-- Form -->
                    <form id="apply-now-form"  method="post" action="<?php echo e(route('voyager.notes.addNewNote')); ?>" enctype="multipart/form-data" class="add-to-do">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" class="event" name="event_id">
                        <p>Details</p>
                        <div class="input-with-icon-left">
                            <div class="form-group">
                                <div>
                                    <textarea name="description" id="user-message" class="form-control" cols="30" rows="10" placeholder=""></textarea>
                                </div>
                            </div>
                            <select id="year" name="priority">
                                <option value="hide">LOW</option>
                                <option >MEDIUM</option>
                                <option >HIGH</option>
                            </select>
                        </div>
                        <div class="withdraw-notes">
                            <button type="button" class="notes-close btn btn-secondary" data-dismiss="modal">Cancel
                            </button>
                            <button type="submit" class="save-event button btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade modal-withdraw"  id="exampleModalCenteredit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered d-flex justify-content-center align-items-center" style="height: 870px;" role="document">
            <div class="modal-content w-100">
                <div style="padding: 20px 45px 50px;">
                    <div class="welcome-text">
                        <h3>Edit <b>Note</b></h3>
                    </div>
                    <!-- Form -->
                    <form method="post" action="<?php echo e(route('voyager.notes.updateNote')); ?>" id="note_edit" class="add-to-do" >
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" class="editNote" name="note_id">
                        <p>Details</p>
                        <div class="input-with-icon-left">
                            <div class="form-group">
                                <div>
                                    <textarea name="description" class="form-control note-description" cols="30" rows="10" placeholder="Meeting with candidate at 3pm who applied for Billingual Event Support Specialist"></textarea>
                                </div>
                            </div>
                            <select name="priority" class="notePriority">
                                <option value="LOW">LOW</option>
                                <option value="MEDIUM" selected>MEDIUM</option>
                                <option value="HIGH">HIGH</option>
                            </select>
                        </div>
                        <div class="withdraw-notes">
                            <button type="button" class="notes-close btn btn-secondary" data-dismiss="modal">Cancel
                            </button>
                            <button type="submit" class="save-event button btn-primary">Save</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <div class="modal fade modal-withdraw"  id="exampleModalCenterEditevent" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered d-flex justify-content-center align-items-center" style="height: 870px;" role="document">
            <div class="modal-content w-100">
                <div style="padding: 20px 45px 50px;">
                    <div class="welcome-text">
                        <h3>Edit</h3>
                    </div>
                    <!-- Form -->
                    <form method="post" action="<?php echo e(route('voyager.events.updates')); ?>" id="editEvent" class="add-event">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" class="eventEdit" name="event_edit_id">
                        <p>Event Title</p>
                        <div class="input-with-icon-left">
                            <div class="form-group">
                                <div>
                                    <input type="text" class="editable" name="title">
                                </div>
                            </div>
                        </div>
                        <div>
                            <p> <i class="time-circle"></i>

                                <input type="datetime-local" id="meeting-time"
                                       name="start_date"
                                       class="event-date">
                                <span style="opacity: 0.4"> PST </span></p>
                        </div>
                        <div>
                            <p> <i class="time-circle"></i>

                                <input type="datetime-local" id="meeting-time-end"
                                       name="end_date"
                                       class="event-date">
                                <span style="opacity: 0.4"> PST </span></p>
                        </div>
                        <div>
                            <i class="calling"> </i>
                            <button class="calling-btn">
                                Add Google Meet video conferencing
                            </button>
                        </div>
                        <p>Details</p>
                        <div class="input-with-icon-left">
                            <div class="form-group">
                                <div>
                                    <textarea name="details"  class="form-control eventDetails" cols="30" rows="5"></textarea>
                                </div>
                            </div>
                        </div>
                        <div>
                            <i class="add-user-event"> </i><input class="add-guests" type="text" placeholder="Add guests">

                        </div>
                        <div>
                            <i class="calendar-event"> </i>
                            <select name="type" id="" class="event-select">
                                <option value="contact">contact</option>Select Event Type
                                <option value="phone">phone</option>
                                <option value="screen">screen</option>
                                <option value="interview">interview</option>
                                <option value="offer call">offer call</option>
                                <option value="questions">questions</option>
                            </select>
                        </div>
                        <div class="withdraw-notes">
                            <button type="button" class="notes-close btn btn-secondary" data-dismiss="modal">Cancel
                            </button>
                            <button type="submit" class="save-event button btn-primary">Schedule</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <div class="modal fade modal-withdraw"  id="exampleModalCenterevent" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered d-flex justify-content-center align-items-center" style="height: 870px;" role="document">
            <div class="modal-content w-100">
                <div style="padding: 20px 45px 50px;">
                    <div class="welcome-text">
                        <h3>New <b>Event</b></h3>
                    </div>
                    <!-- Form -->
                    <form method="post" action="<?php echo e(route('voyager.events.addNewEvent')); ?>" class="add-event">
                        <?php echo e(csrf_field()); ?>

                        <p>Event Title</p>
                        <div class="input-with-icon-left">
                            <div class="form-group">
                                <div>
                                    <input type="text" name="title">
                                </div>
                            </div>
                        </div>
                        <div>
                            <p><i class="time-circle"></i>

                                <input type="datetime-local" id="meeting"
                                       name="start_date"
                                       class="event-date">
                                <span style="opacity: 0.4"> PST </span></p>
                        </div>
                        <div>
                            <p><i class="time-circle"></i>

                                <input type="datetime-local" id="meeting-time-end"
                                       name="end_date"
                                       class="event-date">
                                <span style="opacity: 0.4"> PST </span></p>
                        </div>
                        <div>
                            <i class="calling"> </i>
                            <button class="calling-btn">
                                Add Google Meet video conferencing
                            </button>
                        </div>
                        <p>Details</p>
                        <div class="input-with-icon-left">
                            <div class="form-group">
                                <div>
                                    <textarea name="details"  class="form-control" cols="30" rows="5"></textarea>
                                </div>
                            </div>
                        </div>
                        <div>
                            <i class="add-user-event"> </i><input class="add-guests" type="text" placeholder="Add guests">
                        </div>
                        <div>
                            <i class="calendar-event"> </i>
                            <select name="type" id="" class="event-select">
                                <option value="contact">contact</option>Select Event Type
                                <option value="phone">phone</option>
                                <option value="screen">screen</option>
                                <option value="interview">interview</option>
                                <option value="offer call">offer call</option>
                                <option value="questions">questions</option>
                            </select>
                        </div>
                        <div class="withdraw-notes">
                            <button type="button" class="notes-close btn btn-secondary" data-dismiss="modal">Cancel
                            </button>
                            <button type="submit" class="save-event button btn-primary">Schedule</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <div class="modal fade modal-withdraw"  id="exampleModalCentereventdel" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered d-flex justify-content-center align-items-center" style="height: 870px;" role="document">
            <div class="modal-content w-100">
                <div style="padding: 20px 45px 50px;">
                    <div class="welcome-text-password">
                        <h3 class="text-center margin-bottom-50"><b>Delete</b> from list?</h3>
                    </div>
                    <form action="<?php echo e(route('voyager.notes.remove')); ?>" id="deleteNote" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" class="delNote" name="id">
                        <div class="withdraw-notes">
                            <button type="button" class="notes-close btn btn-secondary" data-dismiss="modal">Cancel
                            </button>
                            <button type="submit" class="withdraw del btn-primary">Delete Item</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('before-script'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js"></script>
    //calendar
    <script>
        $('select').each(function(){
            var $this = $(this), numberOfOptions = $(this).children('option').length;

            $this.addClass('select-hidden');
            $this.wrap('<div class="select"></div>');
            $this.after('<div class="select-styled"></div>');

            var $styledSelect = $this.next('div.select-styled');
            $styledSelect.text($this.children('option').eq(0).text());

            var $list = $('<ul />', {
                'class': 'select-options'
            }).insertAfter($styledSelect);

            for (var i = 0; i < numberOfOptions; i++) {
                $('<li />', {
                    text: $this.children('option').eq(i).text(),
                    rel: $this.children('option').eq(i).val()
                }).appendTo($list);
            }

            var $listItems = $list.children('li');

            $styledSelect.click(function(e) {
                e.stopPropagation();
                $('div.select-styled.active').not(this).each(function(){
                    $(this).removeClass('active').next('ul.select-options').hide();
                });
                $(this).toggleClass('active').next('ul.select-options').toggle();
            });

            $listItems.click(function(e) {
                e.stopPropagation();
                $styledSelect.text($(this).text()).removeClass('active');
                $this.val($(this).attr('rel'));
                $list.hide();
                //console.log($this.val());
            });

            $(document).click(function() {
                $styledSelect.removeClass('active');
                $list.hide();
            });

        });

    </script>
    //calendar notes
    <script>
        $(document).ready(function() {
            $(".remove").click(function (e) {
                e.preventDefault();
                var ele = $(this).data("id");
                console.log(ele);
                $('#deleteNote .delNote').val(ele);
            });
            $(".edit-note").click(function (e) {

            });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/home/dashboard.blade.php ENDPATH**/ ?>