<script src="<?php echo e(asset('js/chatify/code.js')); ?>"></script>
<script>
  // Messenger global variable - 0 by default
  messenger = "<?php echo e(@$id); ?>";
</script>
<?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/messages/footerLinks.blade.php ENDPATH**/ ?>