<?php $__env->startSection('content'); ?>

    <!--sitebar	-->
        <!--	-->


        <!-- Dashboard Content
        ================================================== -->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner" >

                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <div class="d-flex justify-content-between new-condidate-title">
                        <h3>New Team</h3>
                        <p>
                            <a href="#">Cancel</a>
                        </p>
                    </div>
                </div>

                <!-- Row -->
                <div class="row">
                    <!-- Dashboard Box -->
                    <div class="col-xl-12">
                        <div class="dashboard-box margin-top-0">
                            <!-- Headline -->
                            <div class="headline">
                                <h3>Details</h3>
                            </div>
                            <div class="content with-padding padding-bottom-10">
                                <form  action="<?php echo e(route('voyager.users.store')); ?> "
                                       method="POST" enctype="multipart/form-data">
                                    <!-- PUT Method if we are editing -->
                                    <?php echo csrf_field(); ?>
                                    <div class="row new-condidate-inp">

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Name</h5>
                                                <input type="text" class="with-border" placeholder="Full Name" name="name" value="">
                                            </div>
                                        </div>




                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Location
                                                    <i class="icon-material-outline-location-on"></i>
                                                    <!--                                                <img src="" alt="">-->
                                                </h5>
                                                <div class="input-with-icon">
                                                    <div id="autocomplete-container">
                                                        <input id="autocomplete-input" class="with-border" type="text" name="location" value="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Email</h5>
                                                <input type="email" class="with-border" name="email" value="">
                                            </div>
                                        </div>

                                        <div class="col-xl-3">
                                            <div class="submit-field">
                                                <h5>Phone</h5>
                                                <input type="number" class="with-border" name="phone" value="">
                                            </div>
                                        </div>


                                        <div class="col-xl-12">
                                            <div class="submit-field">
                                                <h5>Password</h5>
                                                <input type="password" class="with-border" name="password" value="">
                                            </div>
                                        </div>


                                        <div class="uploadButton col-xl-6 margin-top-30">
                                            <input class="uploadButton-input" type="file" accept="image/*, application/pdf" id="upload" name="avatar" multiple/>
                                            <label class="uploadButton-button ripple-effect" for="upload">Upload Files</label>
                                            <span class="uploadButton-file-name">Resume / CV / Cover Letter / Portfolio </span>
                                        </div>


                                        <div class="col-xl-6 justify-content-end d-flex">
                                            <button class="button ripple-effect big margin-top-30">Add Team</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>

                    </div>



                </div>
                <!-- Row / End -->

                <!-- Footer -->
                <div class="dashboard-footer-spacer"></div>

                <div class="clearfix"></div>
                <!-- Footer / End -->

            </div>
        </div>
        <!-- Dashboard Content / End -->

    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('.select2').select2();

            $("#multipleSelectExample").click(function () {
                $(".select2").select2("open");
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/team/edit-add.blade.php ENDPATH**/ ?>