

<?php $__env->startPush('head'); ?>
    <?php echo $__env->make('voyager::messages.headLinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="dashboard-container">
        <!--sitebar	-->
        <?php echo $__env->make('voyager::dashboard.sidebar_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner" >

                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <h3>Howdy, Tom!</h3>
                    <span>We are glad to see you again!</span>

                    <!-- Breadcrumbs -->
                    <!--				<nav id="breadcrumbs" class="dark">-->
                    <!--					<ul>-->
                    <!--						<li><a href="#">Home</a></li>-->
                    <!--						<li>Dashboard</li>-->
                    <!--					</ul>-->
                    <!--				</nav>-->
                </div>

                <div class="messenger messages-container-inner">

                    <div class="messenger-listView messages-inbox">

                        <div class="m-header">
                            <nav class="d-none-for-remove">
                                <a href="#">
                                    <svg class="svg-inline--fa fa-inbox fa-w-18" aria-hidden="true" focusable="false"
                                         data-prefix="fas" data-icon="inbox" role="img" xmlns="http://www.w3.org/2000/svg"
                                         viewBox="0 0 576 512" data-fa-i2svg="">
                                        <path fill="currentColor"
                                              d="M567.938 243.908L462.25 85.374A48.003 48.003 0 0 0 422.311 64H153.689a48 48 0 0 0-39.938 21.374L8.062 243.908A47.994 47.994 0 0 0 0 270.533V400c0 26.51 21.49 48 48 48h480c26.51 0 48-21.49 48-48V270.533a47.994 47.994 0 0 0-8.062-26.625zM162.252 128h251.497l85.333 128H376l-32 64H232l-32-64H76.918l85.334-128z"></path>
                                    </svg><!-- <i class="fas fa-inbox"></i> --> <span class="messenger-headTitle">No internet access</span>
                                </a>

                                <nav class="m-header-right">
                                    <a href="#">
                                        <svg class="svg-inline--fa fa-cog fa-w-16 settings-btn" aria-hidden="true"
                                             focusable="false" data-prefix="fas" data-icon="cog" role="img"
                                             xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                                            <path fill="currentColor"
                                                  d="M487.4 315.7l-42.6-24.6c4.3-23.2 4.3-47 0-70.2l42.6-24.6c4.9-2.8 7.1-8.6 5.5-14-11.1-35.6-30-67.8-54.7-94.6-3.8-4.1-10-5.1-14.8-2.3L380.8 110c-17.9-15.4-38.5-27.3-60.8-35.1V25.8c0-5.6-3.9-10.5-9.4-11.7-36.7-8.2-74.3-7.8-109.2 0-5.5 1.2-9.4 6.1-9.4 11.7V75c-22.2 7.9-42.8 19.8-60.8 35.1L88.7 85.5c-4.9-2.8-11-1.9-14.8 2.3-24.7 26.7-43.6 58.9-54.7 94.6-1.7 5.4.6 11.2 5.5 14L67.3 221c-4.3 23.2-4.3 47 0 70.2l-42.6 24.6c-4.9 2.8-7.1 8.6-5.5 14 11.1 35.6 30 67.8 54.7 94.6 3.8 4.1 10 5.1 14.8 2.3l42.6-24.6c17.9 15.4 38.5 27.3 60.8 35.1v49.2c0 5.6 3.9 10.5 9.4 11.7 36.7 8.2 74.3 7.8 109.2 0 5.5-1.2 9.4-6.1 9.4-11.7v-49.2c22.2-7.9 42.8-19.8 60.8-35.1l42.6 24.6c4.9 2.8 11 1.9 14.8-2.3 24.7-26.7 43.6-58.9 54.7-94.6 1.5-5.5-.7-11.3-5.6-14.1zM256 336c-44.1 0-80-35.9-80-80s35.9-80 80-80 80 35.9 80 80-35.9 80-80 80z"></path>
                                        </svg><!-- <i class="fas fa-cog settings-btn"></i> --></a>
                                    <a href="#" class="listView-x">
                                        <svg class="svg-inline--fa fa-times fa-w-11" aria-hidden="true" focusable="false"
                                             data-prefix="fas" data-icon="times" role="img" xmlns="http://www.w3.org/2000/svg"
                                             viewBox="0 0 352 512" data-fa-i2svg="">
                                            <path fill="currentColor"
                                                  d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path>
                                        </svg><!-- <i class="fas fa-times"></i> --></a>
                                </nav>
                            </nav>

                            <div class="messages-headline">
                                <div class="input-with-icon">
                                    <input id="autocomplete-input" type="text" placeholder="Search" class="messenger-search">
                                    <i class="icon-material-outline-search"></i>
                                </div>
                            </div>

                            

                            <div class="messenger-listView-tabs d-none-for-remove">
                                <a href="#" <?php if($route == 'user'): ?> class="active-tab" <?php endif; ?> data-view="users">
                                    <span class="far fa-user"></span> People</a>
                                <a href="#" <?php if($route == 'group'): ?> class="active-tab" <?php endif; ?> data-view="groups">
                                    <span class="fas fa-users"></span> Groups</a>
                            </div>
                        </div>

                        <div class="m-body">


                            <div class=" show  messenger-tab app-scroll message-user-list" data-view="users">


                                <p class="messenger-title d-none-for-remove">Favorites</p>
                                <div class="messenger-favorites app-scroll-thin d-none-for-remove"></div>

                                <?php echo view('Chatify::layouts.listItem', ['get' => 'saved','id' => $id])->render(); ?>



                                <div class="listOfContacts" style="width: 100%;height: calc(100% - 200px);"></div>

                            </div>


                            <div class=" messenger-tab app-scroll" data-view="groups">

                                <p style="text-align: center;color:grey;">Soon will be available</p>
                            </div>


                            <div class="messenger-tab app-scroll" data-view="search">

                                <p class="messenger-title">Search</p>
                                <div class="search-records">
                                    <p class="message-hint"><span>Type to search..</span></p>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="messenger-messagingView">

                        <div class="m-header m-header-messaging">
                            <nav class="d-flex justify-content-between w-100">
                                <div style="display: inline-flex;">
                                    <a href="#" class="show-listView">
                                        <svg class="svg-inline--fa fa-arrow-left fa-w-14" aria-hidden="true" focusable="false"
                                             data-prefix="fas" data-icon="arrow-left" role="img"
                                             xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                                            <path fill="currentColor"
                                                  d="M257.5 445.1l-22.2 22.2c-9.4 9.4-24.6 9.4-33.9 0L7 273c-9.4-9.4-9.4-24.6 0-33.9L201.4 44.7c9.4-9.4 24.6-9.4 33.9 0l22.2 22.2c9.5 9.5 9.3 25-.4 34.3L136.6 216H424c13.3 0 24 10.7 24 24v32c0 13.3-10.7 24-24 24H136.6l120.5 114.8c9.8 9.3 10 24.8.4 34.3z"></path>
                                        </svg><!-- <i class="fas fa-arrow-left"></i> --></a>
                                    <div class="avatar av-s header-avatar"
                                         style="margin: 30px 10px; background-image: url(&quot;http://recruitingbitbacket.local/storage/users-avatar/users/default.png&quot;);">
                                    </div>
                                    <a href="#" class="user-name"><?php echo e(config('chatify.name')); ?></a>
                                </div>

                                <nav class="m-header-right ">
                                    <span >Delete Conversation <i class="icon-feather-trash-2-dsh"></i></span>
                                    <span class="icon-trash"></span>
                                </nav>
                            </nav>
                        </div>

                        <div class="internet-connection d-none-for-remove" style="display: block;">
                            <span class="ic-connected" style="display: none;">Connected</span>
                            <span class="ic-connecting" style="display: none;">Connecting...</span>
                            <span class="ic-noInternet" style="display: inline;">No internet access</span>
                        </div>

                        <div class="m-body app-scroll" style="opacity: 1;">
                            <div class="messages">
                                <p class="message-hint" style="margin-top: calc(30% - 126.2px);"><span>Please select a chat to start messaging</span>
                                </p>
                            </div>

                            <div class="typing-indicator">
                                <div class="message-card typing">
                                    <p>
                        <span class="typing-dots">
                            <span class="dot dot-1"></span>
                            <span class="dot dot-2"></span>
                            <span class="dot dot-3"></span>
                        </span>
                                    </p>
                                </div>
                            </div>

                            <?php echo $__env->make('Chatify::layouts.sendForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    </div>
                    <div class="messenger-infoView app-scroll">
                        <nav>
                            <a href="#">
                                <svg class="svg-inline--fa fa-times fa-w-11" aria-hidden="true" focusable="false"
                                     data-prefix="fas"
                                     data-icon="times" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 352 512"
                                     data-fa-i2svg="">
                                    <path fill="currentColor"
                                          d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z"></path>
                                </svg><!-- <i class="fas fa-times"></i> --></a>
                        </nav>
                        <?php echo view('Chatify::layouts.info')->render(); ?>


                    </div>
                </div>


            </div>
        </div>







    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('voyager::messages.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <?php echo $__env->make('voyager::messages.footerLinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('voyager::dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\recruiting\resources\views/vendor/voyager/messages/content.blade.php ENDPATH**/ ?>