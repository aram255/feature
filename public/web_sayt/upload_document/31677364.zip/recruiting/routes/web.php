<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;
use TCG\Voyager\Events\Routing;
use TCG\Voyager\Events\RoutingAdmin;
use TCG\Voyager\Events\RoutingAdminAfter;
use TCG\Voyager\Events\RoutingAfter;
use TCG\Voyager\Facades\Voyager;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/home', function () {
    return view('welcome');
})->name('home');
Route::get('/', ['uses' => 'App\Http\Controllers\IndexController@index',  'as' => 'index']);


use Laravel\Socialite\Facades\Socialite;

Route::get('/auth/redirect', function () {
    return Socialite::driver('github')->redirect();
});

Route::get('/auth/callback', function () {
    $user = Socialite::driver('github')->user();

    // $user->token
});

Route::get('login/{provider}', [App\Http\Controllers\Voyager\VoyagerAuthController::class, 'redirectToProvider']);
Route::get('admin/login/{provider}/callback', [App\Http\Controllers\Voyager\VoyagerAuthController::class, 'handleProviderCallback']);

//Route::get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm');
//Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail');
//Route::get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm');
//Route::post('password/reset', 'Auth\ResetPasswordController@reset');


Route::group(['prefix' => 'admin'], function () {

    Route::group(['as' => 'voyager.'], function () {

        $namespacePrefix = '\\'.config('voyager.controllers.namespace').'\\';
        Route::group(['middleware' => 'admin.user'], function () use ($namespacePrefix) {
            Route::get('users/team', $namespacePrefix.'VoyagerUserController@team')->name('users.team');
            Route::get('users/settings', $namespacePrefix.'VoyagerUserController@settings')->name('users.settings');
            Route::put('candidates/{id}/priority', ['uses' => $namespacePrefix.'VoyagerCandidatesController@priority',        'as' => 'candidates.priority']);
            Route::get('candidates/priority', ['uses' => $namespacePrefix.'VoyagerCandidatesController@priorities',        'as' => 'candidates.priorities']);
            Route::put('jobs/{id}/add-candidate', ['uses' => $namespacePrefix.'VoyagerJobsController@addCandidate',        'as' => 'jobs.addCandidate']);
            Route::post('jobs/{id}/dragdrop', ['uses' => $namespacePrefix.'VoyagerJobsController@dragdrop',        'as' => 'jobs.dragdrop']);
            Route::get('candidates/{id}/profile',['uses' =>  $namespacePrefix.'VoyagerCandidatesController@profile',     'as' => 'candidates.profile']);
        });
    });

    Voyager::routes();


    Route::group(['as' => 'voyager.'], function () {

        $namespacePrefix = '\\'.config('voyager.controllers.namespace').'\\';
        Route::group(['middleware' => 'admin.user'], function () use ($namespacePrefix) {
            Route::get('/', ['uses' => $namespacePrefix.'VoyagerEventsController@index',   'as' => 'dashboard']);


            // Settings
            Route::group([
                'as'     => 'messages.',
                'prefix' => 'messages',
            ], function () use ($namespacePrefix) {
                Route::get('/', ['uses' => $namespacePrefix.'MessagesController@index',        'as' => 'index']);
                Route::get('real', ['uses' => $namespacePrefix.'MessagesController@real',        'as' => 'real']);
            });


            /****Calendar***/
            Route::post('events/addNewEvent', ['uses' => $namespacePrefix.'VoyagerEventsController@addNewEvent',        'as' => 'events.addNewEvent']);
            Route::post('events/updates', ['uses' => $namespacePrefix.'VoyagerEventsController@updates',        'as' => 'events.updates']);
            Route::post('notes/list', ['uses' => $namespacePrefix.'VoyagerNotesController@list',        'as' => 'notes.list']);
            Route::post('notes/addNewNote', ['uses' => $namespacePrefix.'VoyagerNotesController@addNewNote',        'as' => 'notes.addNewNote']);
            Route::post('notes/updateNote', ['uses' => $namespacePrefix.'VoyagerNotesController@update',        'as' => 'notes.updateNote']);
            Route::post('notes/remove', ['uses' => $namespacePrefix.'VoyagerNotesController@remove',        'as' => 'notes.remove']);
            /****Calendar***/


        });
    });
});

//dd(Route::getRoutes());
