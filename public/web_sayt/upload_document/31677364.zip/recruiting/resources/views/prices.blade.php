<div class="row">
    @php
        $dataTypeTools = \Voyager::model('DataType')->where('slug', '=', 'tools')->first();
        $tools = app($dataTypeTools->model_name)->get();
    @endphp

    @foreach($tools as $tool)
        <div class="col-lg-4 col-md-4 col-sm-12 col-12">
            <form action="{{route('voyager.'.$dataTypeTools->slug.'.update', $tool->getKey())}}" method="post">
                @csrf
                @method('PUT')
                <div class="pricing">
                    <div>
                        <h4>{{$tool->name}}</h4>
                        <p>
												<span>
													${{$tool->price_month}}
												</span>
                            / month
                        </p>
                        <span>Billed Monthly</span>
                        <p class="text-amazing">
                            1 Users
                            <br>
                            <br>
                            Unlimited Roles & Candidates
                            <br>
                            <br>
                            Scheduling and Automation
                        </p>
                        <input type="submit" value="Select Plan">
                        <p class="free">Free 7 Day Trail</p>
                    </div>
                </div>
            </form>

        </div>

    @endforeach
</div>
