@extends('layout')
@section('content')
    <div class="">
        <!-- Wrapper -->
        <div id="wrapper mm-page mm-slideout">

            <div class="clearfix"></div>
            <div class="section " >
                <div class="section-bg">
                    <div class="container ">
                        <div class="row">

                            <div class="tool-title">

                                <h1 class="">
                                    Finaly a
                                    <span class=>
                                    <span class="header-sub-title" id="word"></span>|
                                        <!--                                    <span class="header-sub-title blink"></span>-->
                                </span>
                                    <br>
                                    ATS for all!
                                </h1>
                                <p>It’s time to stop using sticky notes and spreadsheets, to try and make <b>applicant</b> tracking <b>possible</b>.</p>
                                <div>
                                    <a href="">
                                        Get Started
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="row banner-sec">
                            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                                <div class="building">
                                    <h1>
                                        Building <b>pipelines</b> has
                                        <br>
                                        never been easier!
                                    </h1>
                                    <div class="d-flex justify-content-between">
                                        <div class="building-col">
                                            <p>
                                                Manage Talent
                                            </p>
                                            <img src="images/rec_index_img/Iconly-1.png" alt="">
                                            <span>
                                         Managing candidates at every stage
                                     </span>
                                        </div>
                                        <div class="building-col">
                                            <p>
                                                Candidate Pools
                                            </p>
                                            <img src="images/rec_index_img/Iconly-2.png" alt="">
                                            <span>
                                         Easily keep up with recruiting pipelines
                                     </span>
                                        </div>
                                        <div class="building-col">
                                            <p>
                                                All in One Place
                                            </p>
                                            <img src="images/rec_index_img/Iconly-3.png" alt="">
                                            <span>
                                         No more flipping between apps
                                     </span>
                                        </div>
                                    </div>
                                </div>

                            </div>




                            <div class="col-lg-6 col-md-12 col-sm-12 col-12 mob-ellips">
                                <div class="ellips-text">
                                    <h1>
                                        Recruiters who <br> <b>switch</b> found
                                    </h1>
                                    <p><span>94%</span><img src="images/rec_index_img/arrow-up.png" alt=""></p>
                                    <p>Increase in prodictivity</p>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <section class="section-bg-1">
                <div class="container">
                    <div class="row">
                        <div class="col-6">
                            <div class="building container">
                                <p>
                                    We partner with recruiters and industry leaders
                                    <br>
                                    to build the simplest ATS possible.
                                </p>
                                <h1>
                                    Simple   <b>Drag-and-drop</b>
                                </h1>
                                <img src="images/rec_index_img/simpl.png" alt="">

                                <p>
                                    management for candidates and roles,
                                    <br>
                                    makes it <b>simple</b> to track every applicant
                                    <br>
                                    at <b>every stage!</b>
                                </p>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="rebust-search">
                                <h1>
                                    Robust  <b>Search</b>
                                </h1>
                                <div class="rebust-bg">
                                    <img src="images/rec_index_img/rebust.png" alt="">
                                </div>
                                <p>
                                    Intuitive search lets you <b>build and manage</b>  candidate pools with <b>ease!</b>
                                </p>

                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="section">
                <div class="section-message container">
                    <div class="row">
                        <div class="col-lg-8 col-md-12 col-sm-12 col-12">
                            <div class="message-title">
                                <h1>
                                    Messaging <span>Built-in</span>
                                </h1>
                                <img src="images/rec_index_img/messages-img.png" alt="">
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 col-sm-12 col-12 message-text">
                            <div>
                                <p>
                                    Never lose track with built-in messaging to keep the <b>whole team connected.</b>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section">
                <div class="section section-amazing-bg">
                    <div class="container">
                        <div class="amazing">
                            <div class="amazing-title">
                                <h1>
                                    Amazing tools don't have to be expensive
                                </h1>
                                <p>
                                    We are dedicated to <b>keeping our platform accessible</b> to
                                    <br>
                                    individuals and all organizations of all sizes
                                </p>
                            </div>
                            <div class="amazing-pricing">
                                <div class="amazing-pricing-title">
                                    <div>
                                        <h1>Pricing</h1>
                                    </div>
                                    <div>
                                        <a id="month" href="#">
                                            Month
                                        </a>
                                        <a id="year" href="#">
                                            Year
                                        </a>
                                    </div>

                                </div>
                                @include('prices')

                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="footer">
                <hr>
                <!-- Footer Top Section -->
                <div class="footer-top-section">
                    <div class="container">
                        <div class="row">
                            <div class="footer-content">
                                <div class="foot-logo" >
                                    <a href="#">
                                        <img src="images/rec_index_img/tool-logo.png" alt="">
                                    </a>
                                </div>
                                <div class="footer-list">
                                    <ul>
                                        <li >
                                            <a href="#">
                                                Prising
                                            </a>
                                        </li>
                                        <span>
                                        |
                                    </span>
                                        <li>
                                            <a href="#">
                                                Login
                                            </a>
                                        </li>
                                        <span>
                                        |
                                    </span>
                                        <li>
                                            <a href="#">
                                                Privacy Policy
                                            </a>
                                        </li>
                                        <span>
                                        |
                                    </span>
                                        <li>
                                            <a href="#">
                                                Termrs & Conditions
                                            </a>
                                        </li>
                                        <span>
                                        |
                                    </span>
                                        <li>
                                            <a href="#">
                                                Reporting
                                            </a>
                                        </li>
                                        <span>
                                        |
                                    </span>
                                        <li>
                                            <a href="#">
                                                Contact Us
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
