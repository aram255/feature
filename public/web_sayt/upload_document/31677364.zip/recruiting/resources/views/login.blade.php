<!doctype html>
<html lang="en">
<head>

    <!-- Basic Page Needs
    ================================================== -->
    <title>LogIn</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="{{asset('css/style.css')}}">
    <link rel="stylesheet" href="{{asset('css/colors/blue.css')}}">
    <link rel="stylesheet" href="{{asset('css/rec_style.css')}}">

</head>
<body>

<!-- Wrapper -->
<div id="wrapper" class="login bg-light-gray" style="height: 100vh">
    <div class="login-bg">
        <div class="container">
            <div class="d-flex flex-wrap justify-content-between align-items-center w-100 px-30 margin-bottom-50">
                <div id="logo">
                    <a href="index.html"><img src="images/rec_images/logo.png" alt=""></a>
                </div>
                <div class="d-flex">
                    <a href="index.html" class="margin-right-40">Home</a>
                    <a href="pages-login.html">Sign Up</a>
                </div>
            </div>
            <div class="container content margin-bottom-60">
                <div class="row">
                    <div class=" col-8 offset-2">
                        <div class="login-register-page margin-top-24">
                            <!-- Welcome Text -->
                            <div class="welcome-text">
                                <h3>Welcome <b>back!</b> <br>
                                    Please Login
                                </h3>
                            </div>

                            <!-- Form -->
                            <form method="post" id="login-form" action="{{ route('voyager.login') }}">
                                @csrf
                                <div class="input-with-icon-left">
                                    <label for="emailaddress">Email</label>
                                    <input type="text" class="input-text with-border" name="email" id="emailaddress" value="{{ old('email') }}" required/>
                                </div>
                                <div class="input-with-icon-left">
                                    <label for="password">Password</label>
                                    <input type="password" class="input-text with-border" name="password" id="password" required/>
                                </div>
                                <div>
                                    <input type="checkbox" name="remember"  value="1"><label for="remember" class="remember-me-text">{{ __('voyager::generic.remember_me') }}</label>
                                </div>




                                <div class="text-right w-100">
                                    <a href="#" class="forgot-password">Forgot Password?</a>
                                </div>
                            </form>

                            <!-- Button -->
                            <button class="button full-width button-sliding-icon ripple-effect margin-top-10" type="submit" form="login-form">Login <i class="icon-material-outline-arrow-right-alt"></i></button>
                            <div class="text-center use-social">
                                <img src="images/rec_images/Line-login.png" alt="">
                                <span>Use Social</span>
                                <img src="images/rec_images/Line-login.png" alt="">
                            </div>
                            <div>
                                <button class="facebook-login ripple-effect">
                                    <a href="{{ url('login/linkedin') }}">
                                        Login with LinkedIn
                                    </a>
                                </button>
                                <button class="google-login ripple-effect">
                                    <a href="{{ url('login/google') }}">
                                        Log In via Google
                                    </a>

                                </button>
                            </div>
                            <!--							<div class="social-login-buttons">-->
                            <!--								<button class="facebook-login ripple-effect"><i class="icon-brand-facebook-f"></i> Log In via Facebook</button>-->
                            <!--								<button class="google-login ripple-effect"><i class="icon-brand-google-plus-g"></i> Log In via Google+</button>-->
                            <!--							</div>-->
                            <div class="margin-top-40 text-center helpe">Don't have an account?<b><a href="pages-register.html"> Create one Here</a></b></div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Wrapper / End -->

<!-- Scripts
================================================== -->
<script src="{{asset('js/jquery-3.4.1.min.js')}}"></script>
<script src="{{asset('js/jquery-migrate-3.1.0.min.js')}}"></script>
<script src="{{asset('js/mmenu.min.js')}}"></script>
<script src="{{asset('js/tippy.all.min.js')}}"></script>
<script src="{{asset('js/simplebar.min.js')}}"></script>
<script src="{{asset('js/bootstrap-slider.min.js')}}"></script>
<script src="{{asset('js/bootstrap-select.min.js')}}"></script>
<script src="{{asset('js/snackbar.js')}}"></script>
<script src="{{asset('js/clipboard.min.js')}}"></script>
<script src="{{asset('js/counterup.min.js')}}"></script>
<script src="{{asset('js/magnific-popup.min.js')}}"></script>
<script src="{{asset('js/slick.min.js')}}"></script>
<script src="{{asset('js/custom.js')}}"></script>

<!-- Snackbar // documentation: https://www.polonel.com/snackbar/ -->
<script>
    // Snackbar for user status switcher
    $('#snackbar-user-status label').click(function() {
        Snackbar.show({
            text: 'Your status has been changed!',
            pos: 'bottom-center',
            showAction: false,
            actionText: "Dismiss",
            duration: 3000,
            textColor: '#fff',
            backgroundColor: '#383838'
        });
    });
</script>

</body>
</html>
