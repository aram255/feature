<?php

declare(strict_types=1);

namespace App\Repositories;


use App\Models\Log;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;


class AlertRepository
{

    /** Get alert data
     * @param $dataTypes select tables
     * @return Builder
     */
    public function getData($dataTypes){

         return Log::when(count($dataTypes), function ($query) use($dataTypes){
            foreach ($dataTypes as $k=>$params){
                $query->orWhere(function($query) use($params) {
                    $query
                        ->where('log_name', $params['table'])
                        ->where('description', $params['action'])
                        ->when($params['json'], function ($query) use($params){
                            $query->where('properties->'.$params['json'], Auth::id());
//                            $query->whereNotNull('properties->'.$params['json']);
                        });
                });
            }
        })->orderByDesc('created_at');
    }
}
