<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {

        Gate::define('team_users', function ($user) {
            return $user->hasPermission('team_users');
        });

        $this->loadViewsFrom(dirname(__DIR__, 4).'/resources/views/', 'Chatify');
    }
}
