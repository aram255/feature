<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;
use TCG\Voyager\Facades\Voyager;
use Throwable;
use Illuminate\Auth\Access\AuthorizationException;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     *
     * @return void
     */
    public function register()
    {

    }

    public function render($request, $exception)
    {
        if ($exception instanceof AuthorizationException) {
            if (in_array(Auth::user()->role->name, config('voyager.roles.manager-roles')))
                return response()->view('voyager::exception.authorization', [], 500);

//            dd(555555);
//            return response()->json([
//                'message' => $exception->getMessage()
//            ], $exception->getStatusCode());
        }

        return parent::render($request, $exception);
    }
}
