<?php

namespace App\Http\Controllers\Voyager;

use App\Events\Viewer;
use App\Models\Candidate;
use App\Models\Range;
use App\Models\Skill;
use App\Models\Tag;
use App\Models\Type;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use TCG\Voyager\Facades\Voyager;
use App\Http\Controllers\Voyager\VoyagerBaseController as BaseVoyagerController;

use App\Models\Job;


class VoyagerJobsController extends BaseVoyagerController
{


    public function index(Request $request)
    {
        // Check permission
        $this->authorize('browse', app(Job::class));

        $searchGroups = [];
        $checkboxs = collect($request->all())->filter(function ($item, $key){
            return preg_match('/\_/', $key) && $item == 'on';
        })->each(function ($item, $key) use (&$searchGroups){
            if (preg_match('/type/', $key))
                $searchGroups['type'][] = str_replace('type_', '', $key);
            elseif(preg_match('/skil/', $key))
                $searchGroups['skill'][] = str_replace('skill_', '', $key);
        });


        $jobs = app(Job::class)
            ->where('user_id', Auth::user()->id)
            ->when($request->get('location'), function ($query, $search){
                return $query->where('location', $search);
            })
            ->when($request->get('range'), function ($query, $search){
                return $query->where('range_id', $search);
            })
            ->when(count($checkboxs), function ($query) use($searchGroups){
                if (array_key_exists('tag', $searchGroups)) {
                    $tags = DB::table('job_tags')->whereIn('tag_id', $searchGroups['tag'])->get()->pluck('job_id');
                    $query->whereIn('id', $tags);
                }
                elseif (array_key_exists('type', $searchGroups)){
                    $query->whereIn('type_id', $searchGroups['type']);
                }
                return $query;
            })
            ->paginate(5);

        $types = Type::where('user_id', Auth::user()->getManagerId())->get();
        $ranges = Range::where('user_id', Auth::user()->getManagerId())->get();
        $tags = Tag::where('user_id', Auth::user()->getManagerId())->get();


        return Voyager::view("voyager::jobs.browse", compact('jobs', 'types', 'ranges', 'tags'));
    }

    public function show(Request $request, $id)
    {
        $job = call_user_func([Job::class, 'findOrFail'], $id);
        // Check permission
        $this->authorize('edit', $job);

        if ($job->user_id != Auth::user()->id)
            abort(401);

        $candidates = Candidate::where('user_id', Auth::user()->id)->get();

        return Voyager::view("voyager::jobs.read", compact('job', 'candidates'));
    }

    public function edit(Request $request, $id)
    {
        $job = call_user_func([Job::class, 'findOrFail'], $id);
        // Check permission
        $this->authorize('edit', $job);


        $types = Type::where('user_id', Auth::user()->getManagerId())->get();
        $tags = Tag::where('user_id', Auth::user()->getManagerId())->get();

        return Voyager::view("voyager::jobs.edit-add", compact('job', 'types', 'tags'));
    }

    public function create(Request $request)
    {
        $job = new Job();
        // Check permission
        $this->authorize('add', $job);


        $types = Type::where('user_id', Auth::user()->getManagerId())->get();
        $tags = Tag::where('user_id', Auth::user()->getManagerId())->get();

        return Voyager::view("voyager::jobs.edit-add", compact('job', 'types', 'tags'));

    }


    public function update(Request $request, $id)
    {
        $job = Job::findOrFail($id);
        if ($job->fill($request->except('images'))->save()){
            $job->tags()->sync($request->input('tags'));
            $addedViewers = collect($request->input('viewers'))->diff($job->viewers->pluck('id'));
            $job->viewers()->sync($request->input('viewers'));
            if ($images = $this->updateOrCreateImages('images','jobs', $request, true)){
                $job->images = $images;
                $job->save();
            }
            //pusher
            foreach ($addedViewers as $viewer){
                event(new Viewer($viewer, [
                            'from'   => Auth::user()->name,
                            'action' => 'applited for a job',
                            'name'   => $job->name
                        ]
                    )
                );
            }
        }

        $redirect = redirect()->back();

        return $redirect->with([
            'message'    => __('voyager::generic.successfully_updated')." Job",
            'alert-type' => 'success',
        ]);
    }


    public function store(Request $request)
    {
        $job = new Job();
        if ($job->fill($request->except('images'))->save()){
            $job->user_id = Auth::user()->id;
            $job->save();
            $job->tags()->sync($request->input('tags'));
            $job->viewers()->sync($request->input('viewers'));
            if ($images = $this->updateOrCreateImages('images','jobs', $request, true)){
                $job->images = $images;
                $job->save();
            }
            //pusher
            foreach ($request->input('viewers') as $viewer){
                event(new Viewer($viewer, [
                            'from'   => Auth::user()->name,
                            'action' => 'applited for a job',
                            'name'   => $job->name
                        ]
                    )
                );
            }
        }

        $redirect = redirect()->back();

        return $redirect->with([
            'message'    => __('voyager::generic.successfully_updated')." Job",
            'alert-type' => 'success',
        ]);
    }


    public function priority(Request $request, $id){

        $job = Job::findOrFail($id);
        $job->priority = true;
        $job->save();


        $redirect = redirect()->back();


        return $redirect->with([
            'message'    => __('voyager::generic.successfully_updated')." Job",
            'alert-type' => 'success',
        ]);


    }


    public function addCandidate(Request $request, $id){

        $job = Job::findOrFail($id);

        $job->leadCandidates()->sync($request->input('candidates'));

        $redirect = redirect()->back();

        return $redirect->with([
            'message'    => __('voyager::generic.successfully_updated')." Job",
            'alert-type' => 'success',
        ]);

    }


    public function dragdrop(Request $request, $id){

        DB::table('job_candidates')->where('id',  $request->input('id'))
            ->update(['progress' => $request->input('progress')]);

        return response()->json(['success'=>'Ok']);

    }

}
