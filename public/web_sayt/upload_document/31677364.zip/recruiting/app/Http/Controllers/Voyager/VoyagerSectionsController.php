<?php

namespace App\Http\Controllers\Voyager;

use App\Models\Range;
use App\Models\Skill;
use App\Models\Tag;
use App\Models\Type;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use TCG\Voyager\Facades\Voyager;
use App\Http\Controllers\Voyager\VoyagerBaseController as BaseVoyagerController;

use App\Models\Job;


class VoyagerSectionsController extends BaseVoyagerController
{


    public function index(Request $request)
    {
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);

        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('browse', app($dataType->model_name));


        $dataTypeContent = app($dataType->model_name)->where('user_id', Auth::user()->getManagerId())->paginate(5);

        return Voyager::view("voyager::sections.browse", compact('dataType', 'dataTypeContent'));
    }

    public function edit(Request $request, $id)
    {
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);

        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('edit', app($dataType->model_name));

        $dataTypeContent = app($dataType->model_name)->findOrFail($id);

        if ($dataTypeContent->user_id != Auth::user()->getManagerId())
            abort(401);

        return Voyager::view("voyager::sections.edit-add", compact('dataType', 'dataTypeContent'));
    }

    public function create(Request $request)
    {

        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);

        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('add', app($dataType->model_name));

        $dataTypeContent = app($dataType->model_name);

        return Voyager::view("voyager::sections.edit-add", compact('dataType', 'dataTypeContent'));

    }


    public function update(Request $request, $id)
    {
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);

        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('edit', app($dataType->model_name));

        $data = app($dataType->model_name)->findOrFail($id);

        if ($data->user_id != Auth::user()->getManagerId())
            abort(401);

        $data->name = $request->input('name');
        $data->user_id = Auth::id();
        $data->save();

        $redirect = redirect()->back();

        return $redirect->with([
            'message'    => __('voyager::generic.successfully_updated')." Job",
            'alert-type' => 'success',
        ]);
    }


    public function store(Request $request)
    {
        // GET THE SLUG, ex. 'posts', 'pages', etc.
        $slug = $this->getSlug($request);

        // GET THE DataType based on the slug
        $dataType = Voyager::model('DataType')->where('slug', '=', $slug)->first();

        // Check permission
        $this->authorize('edit', app($dataType->model_name));

        $data = app($dataType->model_name);
        $data->name = $request->input('name');
        $data->user_id = Auth::id();
        $data->save();

        $redirect = redirect()->back();

        return $redirect->with([
            'message'    => __('voyager::generic.successfully_updated')." Job",
            'alert-type' => 'success',
        ]);
    }

}
