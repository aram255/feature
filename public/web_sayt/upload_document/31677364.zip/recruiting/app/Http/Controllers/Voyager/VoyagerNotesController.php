<?php

namespace App\Http\Controllers\Voyager;
use App\Models\EventNote;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class VoyagerNotesController extends \App\Http\Controllers\Controller
{
    public function list(Request $request)
    {
        return EventNote::where('event_id', $request->id)->get();
    }

    public function addNewNote(Request $request)
    {
        $note = new EventNote();
        $note->fill($request->all())->save();
        return Redirect::to('/admin/');
    }

    function update(Request $r)
    {
        EventNote::find($r->note_id)->fill($r->all())->save();
        return Redirect::to('/admin/');
    }

    public function remove(Request $r)
    {
        EventNote::where("id", $r->id)->delete();

        return Redirect::to('/admin/');
    }
}
