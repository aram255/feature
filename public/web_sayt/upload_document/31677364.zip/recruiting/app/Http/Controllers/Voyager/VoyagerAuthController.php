<?php

namespace App\Http\Controllers\Voyager;

use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Http\Controllers\VoyagerAuthController as BaseVoyagerAuthController;

class VoyagerAuthController extends BaseVoyagerAuthController
{

    public function login()
    {
        if ($this->guard()->user()) {
            return redirect()->route('voyager.dashboard');
        }

        return Voyager::view('login');
    }

    public function redirectToProvider($provider)
    {
        return Socialite::driver($provider)->redirect();
    }
    public function handleProviderCallback($provider)
    {
        try {
            $user = Socialite::driver($provider)->user();
        } catch (\Exception $e) {
            return redirect('/login');
        }
        $authUser = $this->checkUser($user, $provider);

        Auth::login($authUser, true);
        return redirect()->route('voyager.dashboard');
    }
    public function checkUser($providerUser, $provider)
    {
        $account = User::where('provider_name', $provider)
            ->where('provider_id', $providerUser->getId())
            ->first();

        if ($account) {
            return $account;
        } else {
            $user = User::where('email', $providerUser->getEmail())->first();
            if (!$user) {
                $user = new User();
                $user->email = $providerUser->getEmail();
                $user->name = $providerUser->getName();
                $user->email_verified_at = Carbon::now();
                $user->locale = 'en';
                $user->provider_id = $providerUser->getId();
                $user->provider_name = $provider;
                $user->save();
            }
            return $user;
        }
    }
}
