<?php

namespace App\Http\Controllers\Voyager;


use App\Http\Controllers\Voyager\VoyagerBaseController as BaseVoyagerController;
use App\Models\Candidate;
use App\Models\Job;
use App\Models\Range;
use App\Models\Skill;
use App\Models\Type;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use TCG\Voyager\Facades\Voyager;
use TCG\Voyager\Models\Category;
use App\Models\CandidateHistory;


class VoyagerCandidatesController extends BaseVoyagerController
{

    public function index(Request $request)
    {
        // Check permission
        $this->authorize('browse', app(Candidate::class));

        $searchGroups = [];
        $checkboxs = collect($request->all())->filter(function ($item, $key){
            return preg_match('/\_/', $key) && $item == 'on';
        })->each(function ($item, $key) use (&$searchGroups){
            if (preg_match('/type/', $key))
                $searchGroups['type'][] = str_replace('type_', '', $key);
            elseif(preg_match('/skil/', $key))
                $searchGroups['skill'][] = str_replace('skill_', '', $key);
        });
        $candidates = app(Candidate::class)
        ->when($request->input('priority'), function ($query){
            return $query->where('priority', true);
        })
        ->when($request->get('location'), function ($query, $search){
            return $query->where('location', $search);
        })
        ->when($request->get('range'), function ($query, $search){
            return $query->where('range_id', $search);
        })
        ->when(count($checkboxs), function ($query) use($searchGroups){
            if (array_key_exists('skill', $searchGroups)) {
                $skills = DB::table('candidate_skills')->whereIn('skill_id', $searchGroups['skill'])->get()->pluck('candidate_id');
                 $query->whereIn('id', $skills);
            }
            elseif (array_key_exists('type', $searchGroups)){
                 $query->whereIn('type_id', $searchGroups['type']);
            }
            return $query;
        })
        ->paginate(5);

        $types = Type::where('user_id', Auth::user()->getManagerId())->get();
        $ranges = Range::where('user_id', Auth::user()->getManagerId())->get();
        $skills = Skill::where('user_id', Auth::user()->getManagerId())->get();

        return Voyager::view("voyager::candidates.browse", compact('candidates', 'types', 'ranges', 'skills'));
    }


    public function priorities(Request $request)
    {
        // Check permission
        $this->authorize('browse', app(Candidate::class));


        $candidates = app(Candidate::class)->where('priority', true)->paginate(5);

        return Voyager::view("voyager::candidates.priority", compact('candidates'));
    }

    public function show(Request $request, $id)
    {
        $job = call_user_func([Job::class, 'findOrFail'], $id);
        // Check permission
        $this->authorize('edit', $job);

        return Voyager::view("voyager::jobs.read", compact('job'));
    }

    public function edit(Request $request, $id)
    {
        $candidate = call_user_func([Candidate::class, 'findOrFail'], $id);
        // Check permission
        $this->authorize('edit', $candidate);

        $types = Type::where('user_id', Auth::user()->getManagerId())->get();
        $ranges = Range::where('user_id', Auth::user()->getManagerId())->get();
        $skills = Skill::where('user_id', Auth::user()->getManagerId())->get();

        return Voyager::view("voyager::candidates.edit-add", compact('candidate', 'types', 'ranges', 'skills'));
    }

    public function create(Request $request)
    {
        $candidate = new Candidate();
        // Check permission
        $this->authorize('add', $candidate);

        $types = Type::where('user_id', Auth::user()->getManagerId())->get();
        $ranges = Range::where('user_id', Auth::user()->getManagerId())->get();
        $skills = Skill::where('user_id', Auth::user()->getManagerId())->get();

        return Voyager::view("voyager::candidates.edit-add", compact('candidate', 'types', 'ranges', 'skills'));

    }


    public function update(Request $request, $id)
    {
        $candidate = Candidate::findOrFail($id);
        if ($candidate->fill($request->except('files', 'image'))->save()){
            $candidate->skills()->sync($request->input('skills'));
            if ($files = $this->updateOrCreateFiles('files','candidates', $request,true))
                $candidate->files = $files;
            if ($image = $this->updateOrCreateImages('image', 'candidates', $request))
                $candidate->image = $image;
            $data = $request->input('history_title');
            if(is_array($data)) {
                foreach ($data as $i => $value) {
                    $instances[$i] = CandidateHistory::firstOrNew([
                        'id' => $request->input('history_id')[$i],
                    ]);
                    $instances[$i]->title = $request->input('history_title')[$i];
                    $instances[$i]->company = $request->input('history_company')[$i];
                    $instances[$i]->start_date = $request->input('history_start_date')[$i];
                    $instances[$i]->end_date = $request->input('history_end_date')[$i];
                    $instances[$i]->description = $request->input('history_description')[$i];
                }
                $candidate->histories()->saveMany($instances);
            }
            $candidate->save();
        }

        $redirect = redirect()->back();

        return $redirect->with([
            'message'    => __('voyager::generic.successfully_updated')." Job",
            'alert-type' => 'success',
        ]);
    }


    public function store(Request $request)
    {
        $candidate = new Candidate();
        if ($candidate->fill($request->except('files', 'image'))->save()){
            $candidate->skills()->sync($request->input('skills'));
            if ($files = $this->updateOrCreateFiles('files','candidates', $request,true))
                $candidate->files = $files;
            if ($image = $this->updateOrCreateImages('image', 'candidates', $request))
                $candidate->image = $image;
               $data = $request->input('history_title');
               if(is_array($data)) {
                   foreach ($data as $i => $value) {
                       $instances[] = new CandidateHistory([
                           'title' => $request->input('history_title')[$i],
                           'company' => $request->input('history_company')[$i],
                           'start_date' => $request->input('history_start_date')[$i],
                           'end_date' => $request->input('history_end_date')[$i],
                           'description' => $request->input('history_description')[$i]
                       ]);
                   }
                   $candidate->histories()->saveMany($instances);
               }

               $candidate->save();
        }

        $redirect = redirect()->back();

        return $redirect->with([
            'message'    => __('voyager::generic.successfully_updated')." Job",
            'alert-type' => 'success',
        ]);
    }


    public function priority(Request $request, $id){

        $candidate = Candidate::findOrFail($id);
        $candidate->priority = true;
        $candidate->save();


        $redirect = redirect()->back();


        return $redirect->with([
            'message'    => __('voyager::generic.successfully_updated')." Job",
            'alert-type' => 'success',
        ]);


    }
    public function profile(Request $request, $id) {
        $candidate = Candidate::findOrFail($id);
        return Voyager::view("voyager::candidates.profile", compact('candidate'));
    }



}
