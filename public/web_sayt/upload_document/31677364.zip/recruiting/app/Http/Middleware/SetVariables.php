<?php
namespace App\Http\Middleware;

use App\Services\AlertService;
use Closure;
use Illuminate\Contracts\Auth\Guard;

class SetVariables
{
    protected $auth;
    protected $alertService;

    public function __construct(Guard $auth, AlertService $alertService)
    {
        $this->auth = $auth;
        $this->alertService = $alertService;
    }

    public function handle($request, Closure $next)
    {
        $notifications     = $this->alertService->getLastData();
        $notificationsCount = $this->alertService->getUnreadCount();
        \View::share('notifications', $notifications);
        \View::share('notificationsCount', $notificationsCount);

        return $next($request);
    }

}
