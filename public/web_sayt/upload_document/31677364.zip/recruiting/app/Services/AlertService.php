<?php

declare(strict_types=1);

namespace App\Services;



use App\Models\Invoices;
use App\Models\Job;
use App\Models\Log;
use App\Models\User;
use App\Repositories\AlertRepository;
use Carbon\Carbon;

class AlertService
{
    /**
     * @var AlertRepository
     */
    private $alertRepository;

    /**
     * @var DataTypes
     */
    public $dataTypes = [
        //client pay
        'viewers' => [
            'table'  => 'job_viewers',
            'action' => 'pivotAttached',
            'json'   => 'id'
        ],
    ];

    /**
     * @param AlertRepository $alertRepository

     */
    public function __construct(
        AlertRepository $alertRepository
    ) {
        $this->alertRepository = $alertRepository;
    }

    /** Get all alert data
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function get(){
        return $this->alertRepository->getData($this->dataTypes);
    }

    /** Get last records
     * @return array
     */
    public function getLastData(){
        $records = $this->get()->limit(5)->get();
        $this->setDataTypes($records);
        return $this->prepareData($records);
    }

    /** Get unread records
     * @return int
     */
    public function getUnreadCount(){
        return $this->get()->pluck('read')->filter(function ($item){
            return $item>0 ? false : true;
        })->count();
    }

    /** Update unread to read
     */
    public function updateUnreadData(){
        Log::where('read', false)->update(['read' => true]);
    }

    /** Get data
     * @return mixed
     */
    public function getData(){
        $records = $this->get()->paginate(100);
        $items = $records->items();
        $this->setDataTypes($items);
        return $records->setCollection(collect($this->prepareData($items)));
    }

    /** Add filters in log data
     * @param $records
     */
    private function setDataTypes(&$records){
        foreach ($records as &$record){
            foreach ($this->dataTypes as $key => $types){
                if ($record->log_name == $types['table'] && $record->description == $types['action']){
                    if ($types['json']){
                        if (array_key_exists($types['json'],$record->properties))
                            $record->prepare = $key;
                    }
                    else{
                        $record->prepare = $key;
                    }
                }

            }
        }
    }

    /**
     * @param $records
     * @return array
     */
    private function prepareData($records){
        $array = [];
        foreach ($records as $record){
            try{
                $date = Carbon::createFromFormat('Y-m-d H:i:s', $record->created_at, 'Europe/Moscow');
                $date->setTimezone('UTC');
                $record->created_at = $date;
                $action = 'prepare'. ucfirst($record->prepare) .'Data';
                $array[] = $this->$action($record);
            }
            catch (\Exception $e){
                $array[] = $this->prepareBagData($record);
            }
        }

        return $array;
    }

    private function prepareBagData($record){
        return '<p '.(!$record->read ? "style='background-color:silver'" : '').'><i class="fas fa-exclamation"></i> Bag <span class="pull-right text-muted small">'.Carbon::parse($record->created_at)->diffForHumans().'</span></p>';
    }

    private function prepareViewersData($record){

        $text = '<li '.(!$record->read ? "style='background-color:silver'" : '').'  class="notifications-not-read"><a href="dashboard-manage-candidates.html"><span class="notification-icon"><i class="icon-material-outline-group"></i></span><span class="notification-text"> <strong>%s</strong> %s <span class="color">%s</span> </span> </a> </li>';

        $user = User::findOrFail($record->causer_id);
        $job = Job::findOrFail($record->subject_id);

            return sprintf($text, $user->name, 'applited for a job', $job->name);

//        return sprintf($text, $hire->id, 'paid', round($invoice->amount).'$', Carbon::parse($record->properties['created_at'])->diffForHumans());
    }

}
