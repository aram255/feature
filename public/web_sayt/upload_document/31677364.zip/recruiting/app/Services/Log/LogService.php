<?php

namespace App\Services\Log;


use App\Models\User;
use Illuminate\Support\Facades\Auth;

class LogService
{

    public static function add($data)
    {
        $user = Auth::user();

        activity($data->slug)
            ->performedOn($data->performed)
            ->causedBy($user)
            ->withProperties($data->properties)
            ->log($data->method);

        return true;
    }

    public static function prepareAndAddData($action, $table, $model, $data)
    {
        return self::add(
            (object)[
                'slug' => $table ,
                'performed' => $model,
                'properties' => $data,
                'method' => $action
            ]
        );
    }
}
