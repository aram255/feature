<?php

namespace App;


class User extends Models\User
{
}
