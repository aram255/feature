<?php

namespace App\Models;


class Tool extends BaseModel
{

}
