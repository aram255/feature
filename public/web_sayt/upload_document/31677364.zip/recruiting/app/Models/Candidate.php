<?php

namespace App\Models;

class Candidate extends BaseModel
{

    protected $fillable = ['name', 'type_id', 'range_id', 'country', 'linkdin', 'location', 'email', 'phone', 'portfolio', 'about', 'files', 'priority', 'image'];

    public function type(){
        return $this->belongsTo(Type::class, 'type_id');
    }

    public function range(){
        return $this->belongsTo(Range::class, 'range_id');
    }

    public function skills(){
        return $this->belongsToMany(Skill::class, 'candidate_skills','candidate_id', 'skill_id');
    }

    public function histories(){
        return $this->hasMany(CandidateHistory::class,'candidate_id','id');
    }

}
