<?php

namespace App\Models;

class Tag extends BaseModel
{

}
