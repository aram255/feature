<?php

namespace App\Models;


class CandidateHistory extends BaseModel
{
    protected $fillable = ['candidate_id', 'title', 'company', 'description','start_date','end_date'];

    protected $primaryKey = 'id';

    public function candidate(){
        return $this->belongsTo(Candidate::class,'candidate_id');
    }
}
