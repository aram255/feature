<?php

namespace App\Models;

class Skill extends BaseModel
{

}
