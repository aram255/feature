<?php

namespace App\Models;

use App\Services\Log\LogService;
use GeneaLabs\LaravelPivotEvents\Traits\PivotEventTrait;
use Illuminate\Database\Eloquent\Model;


abstract class BaseModel extends Model
{
    use PivotEventTrait;



    public static function boot()
    {
        parent::boot();

//
        static::pivotAttached(function ($model, $relationName, $pivotIds, $pivotIdsAttributes) {
            if ($className = strrpos(get_class($model), '\\'))
                $className =  substr(get_class($model), $className + 1);
            LogService::prepareAndAddData('pivotAttached', strtolower($className).'_'.$pivotIds,  $model, ['id' => $pivotIdsAttributes[0]]);
        });

        static::updated(function ($model, $data) {
            LogService::prepareAndAddData('updated', $model->getTable(),  $model, $model->getAttributes());
        });


    }

}
