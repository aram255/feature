<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends \TCG\Voyager\Models\User
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'email',
        'email_verified_at',
        'settings',
        'password',
        'provider_name',
        'provider_id',
        'parent_id',
        'location',
        'phone',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function parent(){
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function children(){
        return $this->hasMany(self::class, 'parent_id');
    }


    public function isMember(){
        return in_array($this->role->name, config('voyager.roles.member-roles'));
    }

    public function isViewer(){
        return in_array($this->role->name, config('voyager.roles.viewer-roles'));
    }


    public function isManager(){
        return in_array($this->role->name, config('voyager.roles.manager-roles'));
    }

    public function getManager(){
        return $this->parent()->first() ?? $this;
    }

    public function getManagerId(){
        return $this->getManager()->id;
    }

    public function getTeam(){
        return $this->isManager()
            ? $this->children()->get()
            : $this->getManager()->children()->get()->filter(function ($member){
                return !$member->id == $this->id;
            })->push($this->getManager());
    }

}
