<?php

namespace App\Models;


class Log extends \Spatie\Activitylog\Models\Activity
{
    public function getPropertiesAttribute($value){
        return json_decode(!empty($value) ? $value : '[]',true);
    }

}
