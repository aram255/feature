<?php

namespace App\Models;

use App\Services\Log\LogService;
use GeneaLabs\LaravelPivotEvents\Traits\PivotEventTrait;


class Job extends BaseModel
{
    protected $fillable = ['id', 'name', 'description', 'location', 'start_range', 'end_range', 'type_id', 'range_id', 'images'];


    public function type(){
        return $this->belongsTo(Type::class, 'type_id');
    }

    public function tags(){
        return $this->belongsToMany(Tag::class, 'job_tags','job_id', 'tag_id');
    }

    public function candidates(){
        return $this->belongsToMany(Candidate::class, 'job_candidates','job_id', 'candidate_id')->withPivot('id');
    }

    public function viewers(){
        return $this->belongsToMany(User::class, 'job_viewers','job_id', 'user_id');
    }

    public function leadCandidates(){
        return $this->candidates()->where('progress', 'lead');
    }

    public function screenCandidates(){
        return $this->candidates()->where('progress', 'screen');
    }

    public function interviewCandidates(){
        return $this->candidates()->where('progress', 'interview');
    }

    public function offerCandidates(){
        return $this->candidates()->where('progress', 'offer');
    }
}
