<?php

namespace App\Models;

class Range extends BaseModel
{

}
