<?php
namespace App\Models;


class EventNote extends BaseModel
{
    protected $fillable = ['id','description','priority','event_id'];

    public function event() {
        return $this->belongsTo('App\Models\Event');
    }
}
