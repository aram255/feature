<?php

namespace App\Models;

class Event extends BaseModel
{
    protected $fillable = ['title','start_date','end_date','type','details','user_id'];

    public function notes()
    {
        return $this->hasMany('App\Models\EventNote','event_id');
    }
}
